TRUNCATE public."_articles_v", public."_articles_v_locales", public."_pages_v", public."_pages_v_blocks_accordion", public."_pages_v_blocks_accordion_items", public."_pages_v_blocks_article_feed", public."_pages_v_blocks_article_feed_sites", public."_pages_v_blocks_cards", public."_pages_v_blocks_cards_items", public."_pages_v_blocks_child_pages", public."_pages_v_blocks_content", public."_pages_v_blocks_cta", public."_pages_v_blocks_cta_links", public."_pages_v_blocks_documents", public."_pages_v_blocks_embed", public."_pages_v_blocks_facts", public."_pages_v_blocks_facts_items", public."_pages_v_blocks_form_block", public."_pages_v_blocks_full_image", public."_pages_v_blocks_hero", public."_pages_v_blocks_hero_links", public."_pages_v_blocks_image_grid", public."_pages_v_blocks_image_grid_images", public."_pages_v_blocks_people", public."_pages_v_blocks_quote", public."_pages_v_blocks_stats", public."_pages_v_blocks_stats_bars", public."_pages_v_blocks_stats_items", public."_pages_v_blocks_text_image", public."_pages_v_blocks_text_image_links", public."_pages_v_blocks_timeline", public."_pages_v_blocks_timeline_items", public."_pages_v_blocks_video", public."_pages_v_locales", public."_pages_v_rels", public."analytics_daily", public."analytics_events", public."analytics_salts", public."analytics_settings", public."articles", public."articles_locales", public."audit_log", public."consent_log", public."documents", public."documents_locales", public."documents_sites", public."forms", public."forms_blocks_checkbox", public."forms_blocks_checkbox_locales", public."forms_blocks_country", public."forms_blocks_country_locales", public."forms_blocks_email", public."forms_blocks_email_locales", public."forms_blocks_message", public."forms_blocks_message_locales", public."forms_blocks_number", public."forms_blocks_number_locales", public."forms_blocks_select", public."forms_blocks_select_locales", public."forms_blocks_select_options", public."forms_blocks_select_options_locales", public."forms_blocks_text", public."forms_blocks_text_locales", public."forms_blocks_textarea", public."forms_blocks_textarea_locales", public."forms_emails", public."forms_emails_locales", public."forms_locales", public."media", public."media_locales", public."pages", public."pages_blocks_accordion", public."pages_blocks_accordion_items", public."pages_blocks_article_feed", public."pages_blocks_article_feed_sites", public."pages_blocks_cards", public."pages_blocks_cards_items", public."pages_blocks_child_pages", public."pages_blocks_content", public."pages_blocks_cta", public."pages_blocks_cta_links", public."pages_blocks_documents", public."pages_blocks_embed", public."pages_blocks_facts", public."pages_blocks_facts_items", public."pages_blocks_form_block", public."pages_blocks_full_image", public."pages_blocks_hero", public."pages_blocks_hero_links", public."pages_blocks_image_grid", public."pages_blocks_image_grid_images", public."pages_blocks_people", public."pages_blocks_quote", public."pages_blocks_stats", public."pages_blocks_stats_bars", public."pages_blocks_stats_items", public."pages_blocks_text_image", public."pages_blocks_text_image_links", public."pages_blocks_timeline", public."pages_blocks_timeline_items", public."pages_blocks_video", public."pages_locales", public."pages_rels", public."payload_folders", public."payload_folders_folder_type", public."people", public."people_locales", public."redirects", public."redirects_rels", public."search_index", public."site_settings", public."site_settings_footer_columns", public."site_settings_footer_columns_links", public."site_settings_legal_links", public."site_settings_locales", public."site_settings_nav", public."site_settings_nav_children", public."site_settings_rels", public."site_settings_social" RESTART IDENTITY CASCADE;
SET CONSTRAINTS ALL DEFERRED;
SET session_replication_role = 'replica';
SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;
INSERT INTO public.media (id, credit, prefix, _objectkey, folder_id, updated_at, created_at, url, thumbnail_u_r_l, filename, mime_type, filesize, width, height, focal_x, focal_y, sizes_thumb_url, sizes_thumb_width, sizes_thumb_height, sizes_thumb_mime_type, sizes_thumb_filesize, sizes_thumb_filename, sizes_sm_url, sizes_sm_width, sizes_sm_height, sizes_sm_mime_type, sizes_sm_filesize, sizes_sm_filename, sizes_md_url, sizes_md_width, sizes_md_height, sizes_md_mime_type, sizes_md_filesize, sizes_md_filename, sizes_lg_url, sizes_lg_width, sizes_lg_height, sizes_lg_mime_type, sizes_lg_filesize, sizes_lg_filename, sizes_xl_url, sizes_xl_width, sizes_xl_height, sizes_xl_mime_type, sizes_xl_filesize, sizes_xl_filename, sizes_og_url, sizes_og_width, sizes_og_height, sizes_og_mime_type, sizes_og_filesize, sizes_og_filename) VALUES
	(1, NULL, 'public/media', NULL, NULL, '2026-10-11 11:46:54.171+00', '2026-10-11 11:46:54.158+00', '/api/media/file/hero.jpg', '/api/media/file/hero-400x225.webp', 'hero.jpg', 'image/jpeg', 15027, 1600, 900, 50, 50, '/api/media/file/hero-400x225.webp', 400, 225, 'image/webp', 1586, 'hero-400x225.webp', '/api/media/file/hero-768x432.webp', 768, 432, 'image/webp', 3652, 'hero-768x432.webp', '/api/media/file/hero-1280x720.webp', 1280, 720, 'image/webp', 7442, 'hero-1280x720.webp', '/api/media/file/hero-1600x900.webp', 1600, 900, 'image/webp', 10614, 'hero-1600x900.webp', '/api/media/file/hero-1600x900.webp', 1600, 900, 'image/webp', 10614, 'hero-1600x900.webp', '/api/media/file/hero-1200x630.webp', 1200, 630, 'image/webp', 6644, 'hero-1200x630.webp'),
	(2, NULL, 'public/media', NULL, NULL, '2026-10-11 11:46:54.248+00', '2026-10-11 11:46:54.237+00', '/api/media/file/office.jpg', '/api/media/file/office-400x250.webp', 'office.jpg', 'image/jpeg', 17822, 1600, 1000, 50, 50, '/api/media/file/office-400x250.webp', 400, 250, 'image/webp', 2030, 'office-400x250.webp', '/api/media/file/office-768x480.webp', 768, 480, 'image/webp', 4824, 'office-768x480.webp', '/api/media/file/office-1280x800.webp', 1280, 800, 'image/webp', 9776, 'office-1280x800.webp', '/api/media/file/office-1600x1000.webp', 1600, 1000, 'image/webp', 14294, 'office-1600x1000.webp', '/api/media/file/office-1600x1000.webp', 1600, 1000, 'image/webp', 14294, 'office-1600x1000.webp', '/api/media/file/office-1200x630.webp', 1200, 630, 'image/webp', 8180, 'office-1200x630.webp'),
	(3, NULL, 'public/media', NULL, NULL, '2026-10-11 11:46:54.327+00', '2026-10-11 11:46:54.315+00', '/api/media/file/workshop.jpg', '/api/media/file/workshop-400x250.webp', 'workshop.jpg', 'image/jpeg', 17938, 1600, 1000, 50, 50, '/api/media/file/workshop-400x250.webp', 400, 250, 'image/webp', 2112, 'workshop-400x250.webp', '/api/media/file/workshop-768x480.webp', 768, 480, 'image/webp', 5098, 'workshop-768x480.webp', '/api/media/file/workshop-1280x800.webp', 1280, 800, 'image/webp', 10752, 'workshop-1280x800.webp', '/api/media/file/workshop-1600x1000.webp', 1600, 1000, 'image/webp', 16210, 'workshop-1600x1000.webp', '/api/media/file/workshop-1600x1000.webp', 1600, 1000, 'image/webp', 16210, 'workshop-1600x1000.webp', '/api/media/file/workshop-1200x630.webp', 1200, 630, 'image/webp', 8812, 'workshop-1200x630.webp'),
	(4, NULL, 'public/media', NULL, NULL, '2026-10-11 11:46:54.406+00', '2026-10-11 11:46:54.396+00', '/api/media/file/fjord.jpg', '/api/media/file/fjord-400x225.webp', 'fjord.jpg', 'image/jpeg', 15898, 1600, 900, 50, 50, '/api/media/file/fjord-400x225.webp', 400, 225, 'image/webp', 1708, 'fjord-400x225.webp', '/api/media/file/fjord-768x432.webp', 768, 432, 'image/webp', 4110, 'fjord-768x432.webp', '/api/media/file/fjord-1280x720.webp', 1280, 720, 'image/webp', 8210, 'fjord-1280x720.webp', '/api/media/file/fjord-1600x900.webp', 1600, 900, 'image/webp', 12176, 'fjord-1600x900.webp', '/api/media/file/fjord-1600x900.webp', 1600, 900, 'image/webp', 12176, 'fjord-1600x900.webp', '/api/media/file/fjord-1200x630.webp', 1200, 630, 'image/webp', 7394, 'fjord-1200x630.webp'),
	(5, NULL, 'public/media', NULL, NULL, '2026-10-11 11:46:54.48+00', '2026-10-11 11:46:54.469+00', '/api/media/file/coast.jpg', '/api/media/file/coast-400x225.webp', 'coast.jpg', 'image/jpeg', 15444, 1600, 900, 50, 50, '/api/media/file/coast-400x225.webp', 400, 225, 'image/webp', 1566, 'coast-400x225.webp', '/api/media/file/coast-768x432.webp', 768, 432, 'image/webp', 3874, 'coast-768x432.webp', '/api/media/file/coast-1280x720.webp', 1280, 720, 'image/webp', 7690, 'coast-1280x720.webp', '/api/media/file/coast-1600x900.webp', 1600, 900, 'image/webp', 11196, 'coast-1600x900.webp', '/api/media/file/coast-1600x900.webp', 1600, 900, 'image/webp', 11196, 'coast-1600x900.webp', '/api/media/file/coast-1200x630.webp', 1200, 630, 'image/webp', 6902, 'coast-1200x630.webp'),
	(6, NULL, 'public/media', NULL, NULL, '2026-10-11 11:46:54.549+00', '2026-10-11 11:46:54.539+00', '/api/media/file/portrait-kari.jpg', '/api/media/file/portrait-kari-400x400.webp', 'portrait-kari.jpg', 'image/jpeg', 8879, 800, 800, 50, 50, '/api/media/file/portrait-kari-400x400.webp', 400, 400, 'image/webp', 2404, 'portrait-kari-400x400.webp', '/api/media/file/portrait-kari-768x768.webp', 768, 768, 'image/webp', 5530, 'portrait-kari-768x768.webp', '/api/media/file/portrait-kari-800x800.webp', 800, 800, 'image/webp', 5912, 'portrait-kari-800x800.webp', '/api/media/file/portrait-kari-800x800.webp', 800, 800, 'image/webp', 5912, 'portrait-kari-800x800.webp', '/api/media/file/portrait-kari-800x800.webp', 800, 800, 'image/webp', 5912, 'portrait-kari-800x800.webp', '/api/media/file/portrait-kari-800x630.webp', 800, 630, 'image/webp', 4974, 'portrait-kari-800x630.webp'),
	(7, NULL, 'public/media', NULL, NULL, '2026-10-11 11:46:54.608+00', '2026-10-11 11:46:54.599+00', '/api/media/file/portrait-ola.jpg', '/api/media/file/portrait-ola-400x400.webp', 'portrait-ola.jpg', 'image/jpeg', 9763, 800, 800, 50, 50, '/api/media/file/portrait-ola-400x400.webp', 400, 400, 'image/webp', 2722, 'portrait-ola-400x400.webp', '/api/media/file/portrait-ola-768x768.webp', 768, 768, 'image/webp', 6458, 'portrait-ola-768x768.webp', '/api/media/file/portrait-ola-800x800.webp', 800, 800, 'image/webp', 7154, 'portrait-ola-800x800.webp', '/api/media/file/portrait-ola-800x800.webp', 800, 800, 'image/webp', 7154, 'portrait-ola-800x800.webp', '/api/media/file/portrait-ola-800x800.webp', 800, 800, 'image/webp', 7154, 'portrait-ola-800x800.webp', '/api/media/file/portrait-ola-800x630.webp', 800, 630, 'image/webp', 5980, 'portrait-ola-800x630.webp'),
	(8, NULL, 'public/media', NULL, NULL, '2026-10-11 11:46:54.674+00', '2026-10-11 11:46:54.665+00', '/api/media/file/news.jpg', '/api/media/file/news-400x225.webp', 'news.jpg', 'image/jpeg', 16587, 1600, 900, 50, 50, '/api/media/file/news-400x225.webp', 400, 225, 'image/webp', 1660, 'news-400x225.webp', '/api/media/file/news-768x432.webp', 768, 432, 'image/webp', 3936, 'news-768x432.webp', '/api/media/file/news-1280x720.webp', 1280, 720, 'image/webp', 7784, 'news-1280x720.webp', '/api/media/file/news-1600x900.webp', 1600, 900, 'image/webp', 10608, 'news-1600x900.webp', '/api/media/file/news-1600x900.webp', 1600, 900, 'image/webp', 10608, 'news-1600x900.webp', '/api/media/file/news-1200x630.webp', 1200, 630, 'image/webp', 6978, 'news-1200x630.webp');
INSERT INTO public.articles (id, hero_image_id, site, kind, published_at, updated_at, created_at, _status) VALUES
	(1, 8, 'main', 'news', '2026-10-01 09:00:00+00', '2026-10-11 11:46:56.741+00', '2026-10-11 11:46:56.727+00', 'published'),
	(2, 2, 'main', 'news', '2026-09-15 09:00:00+00', '2026-10-11 11:46:56.767+00', '2026-10-11 11:46:56.755+00', 'published'),
	(3, 3, 'main', 'blog', '2026-08-20 09:00:00+00', '2026-10-11 11:46:56.794+00', '2026-10-11 11:46:56.782+00', 'published');
INSERT INTO public._articles_v (id, parent_id, version_hero_image_id, version_site, version_kind, version_published_at, version_updated_at, version_created_at, version__status, created_at, updated_at, snapshot, published_locale, latest, autosave) VALUES
	(2, 1, 8, 'main', 'news', '2026-10-01 09:00:00+00', '2026-10-11 11:46:56.741+00', '2026-10-11 11:46:56.727+00', 'published', '2026-10-11 11:46:56.743+00', '2026-10-11 11:46:56.743+00', NULL, NULL, true, false),
	(1, 1, 8, 'main', 'news', '2026-10-01 09:00:00+00', '2026-10-11 11:46:56.727+00', '2026-10-11 11:46:56.727+00', 'published', '2026-10-11 11:46:56.729+00', '2026-10-11 11:46:56.729+00', NULL, NULL, false, false),
	(4, 2, 2, 'main', 'news', '2026-09-15 09:00:00+00', '2026-10-11 11:46:56.767+00', '2026-10-11 11:46:56.755+00', 'published', '2026-10-11 11:46:56.768+00', '2026-10-11 11:46:56.768+00', NULL, NULL, true, false),
	(3, 2, 2, 'main', 'news', '2026-09-15 09:00:00+00', '2026-10-11 11:46:56.755+00', '2026-10-11 11:46:56.755+00', 'published', '2026-10-11 11:46:56.756+00', '2026-10-11 11:46:56.756+00', NULL, NULL, false, false),
	(6, 3, 3, 'main', 'blog', '2026-08-20 09:00:00+00', '2026-10-11 11:46:56.794+00', '2026-10-11 11:46:56.782+00', 'published', '2026-10-11 11:46:56.796+00', '2026-10-11 11:46:56.796+00', NULL, NULL, true, false),
	(5, 3, 3, 'main', 'blog', '2026-08-20 09:00:00+00', '2026-10-11 11:46:56.782+00', '2026-10-11 11:46:56.782+00', 'published', '2026-10-11 11:46:56.783+00', '2026-10-11 11:46:56.783+00', NULL, NULL, false, false);
INSERT INTO public._articles_v_locales (version_title, version_lead, version_content, version_meta_title, version_meta_image_id, version_meta_description, version_meta_noindex, version_slug, id, _locale, _parent_id) VALUES
	('Nytt nettsted på Hosait', 'Vi har flyttet nettstedet.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Nettstedet kjører nå på Hosait Site Kit.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'nytt-nettsted-pa-hosait', 1, 'no', 1),
	('Nytt nettsted på Hosait', 'Vi har flyttet nettstedet.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Nettstedet kjører nå på Hosait Site Kit.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'nytt-nettsted-pa-hosait', 2, 'no', 2),
	('New website on Hosait', 'We have moved our website.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The website now runs on Hosait Site Kit.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'new-website-on-hosait', 3, 'en', 2),
	('Nytt kontor i Oslo', 'Vi har åpnet kontor i Oslo.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Velkommen innom.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'nytt-kontor-i-oslo', 4, 'no', 3),
	('Nytt kontor i Oslo', 'Vi har åpnet kontor i Oslo.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Velkommen innom.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'nytt-kontor-i-oslo', 5, 'no', 4),
	('New office in Oslo', 'We have opened an office in Oslo.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Drop by.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'new-office-in-oslo', 6, 'en', 4),
	('Tre råd om digital strategi', 'Kort fortalt.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "1. Start smått", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Velg ett mål.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "2. Mål", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Følg med på tallene.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "3. Juster", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Gjør små endringer ofte.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'tre-rad-om-digital-strategi', 7, 'no', 5),
	('Tre råd om digital strategi', 'Kort fortalt.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "1. Start smått", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Velg ett mål.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "2. Mål", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Følg med på tallene.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "3. Juster", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Gjør små endringer ofte.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'tre-rad-om-digital-strategi', 8, 'no', 6),
	('Three tips on digital strategy', 'In short.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "1. Start small", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Pick one goal.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "2. Measure", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Watch the numbers.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "3. Adjust", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Make small changes often.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'three-tips-on-digital-strategy', 9, 'en', 6);
INSERT INTO public.pages (id, site, is_home, parent_id, "order", card_image_id, hide_from_nav, updated_at, created_at, _status) VALUES
	(1, 'main', true, NULL, NULL, NULL, NULL, '2026-10-11 11:46:55.712+00', '2026-10-11 11:46:54.823+00', 'published'),
	(2, 'main', false, NULL, 1, 4, NULL, '2026-10-11 11:46:55.87+00', '2026-10-11 11:46:54.931+00', 'published'),
	(3, 'main', false, NULL, 2, 3, NULL, '2026-10-11 11:46:55.979+00', '2026-10-11 11:46:55.016+00', 'published'),
	(4, 'main', false, 3, 1, 3, NULL, '2026-10-11 11:46:56.139+00', '2026-10-11 11:46:55.109+00', 'published'),
	(5, 'main', false, 3, 2, 2, NULL, '2026-10-11 11:46:56.26+00', '2026-10-11 11:46:55.206+00', 'published'),
	(6, 'main', false, NULL, 3, NULL, NULL, '2026-10-11 11:46:56.371+00', '2026-10-11 11:46:55.309+00', 'published'),
	(7, 'main', false, NULL, 4, NULL, NULL, '2026-10-11 11:46:56.488+00', '2026-10-11 11:46:55.394+00', 'published'),
	(8, 'main', false, NULL, 9, NULL, true, '2026-10-11 11:46:56.589+00', '2026-10-11 11:46:55.473+00', 'published'),
	(9, 'main', false, NULL, 10, NULL, true, '2026-10-11 11:46:56.686+00', '2026-10-11 11:46:55.555+00', 'published');
INSERT INTO public._pages_v (id, parent_id, version_site, version_is_home, version_parent_id, version_order, version_card_image_id, version_hide_from_nav, version_updated_at, version_created_at, version__status, created_at, updated_at, snapshot, published_locale, latest, autosave) VALUES
	(20, 1, 'main', true, NULL, NULL, NULL, NULL, '2026-10-11 11:46:55.712+00', '2026-10-11 11:46:54.823+00', 'published', '2026-10-11 11:46:55.728+00', '2026-10-11 11:46:55.728+00', NULL, NULL, true, false),
	(1, 1, 'main', true, NULL, NULL, NULL, NULL, '2026-10-11 11:46:54.823+00', '2026-10-11 11:46:54.823+00', 'published', '2026-10-11 11:46:54.841+00', '2026-10-11 11:46:54.841+00', NULL, NULL, false, false),
	(19, 1, 'main', true, NULL, NULL, NULL, NULL, '2026-10-11 11:46:55.648+00', '2026-10-11 11:46:54.823+00', 'published', '2026-10-11 11:46:55.665+00', '2026-10-11 11:46:55.665+00', NULL, NULL, false, false),
	(2, 1, 'main', true, NULL, NULL, NULL, NULL, '2026-10-11 11:46:54.886+00', '2026-10-11 11:46:54.823+00', 'published', '2026-10-11 11:46:54.896+00', '2026-10-11 11:46:54.896+00', NULL, NULL, false, false),
	(22, 2, 'main', false, NULL, 1, 4, NULL, '2026-10-11 11:46:55.87+00', '2026-10-11 11:46:54.931+00', 'published', '2026-10-11 11:46:55.882+00', '2026-10-11 11:46:55.882+00', NULL, NULL, true, false),
	(3, 2, 'main', false, NULL, 1, 4, NULL, '2026-10-11 11:46:54.931+00', '2026-10-11 11:46:54.931+00', 'published', '2026-10-11 11:46:54.936+00', '2026-10-11 11:46:54.936+00', NULL, NULL, false, false),
	(21, 2, 'main', false, NULL, 1, 4, NULL, '2026-10-11 11:46:55.811+00', '2026-10-11 11:46:54.931+00', 'published', '2026-10-11 11:46:55.824+00', '2026-10-11 11:46:55.824+00', NULL, NULL, false, false),
	(4, 2, 'main', false, NULL, 1, 4, NULL, '2026-10-11 11:46:54.971+00', '2026-10-11 11:46:54.931+00', 'published', '2026-10-11 11:46:54.981+00', '2026-10-11 11:46:54.981+00', NULL, NULL, false, false),
	(24, 3, 'main', false, NULL, 2, 3, NULL, '2026-10-11 11:46:55.979+00', '2026-10-11 11:46:55.016+00', 'published', '2026-10-11 11:46:55.99+00', '2026-10-11 11:46:55.99+00', NULL, NULL, true, false),
	(5, 3, 'main', false, NULL, 2, 3, NULL, '2026-10-11 11:46:55.016+00', '2026-10-11 11:46:55.016+00', 'published', '2026-10-11 11:46:55.022+00', '2026-10-11 11:46:55.022+00', NULL, NULL, false, false),
	(23, 3, 'main', false, NULL, 2, 3, NULL, '2026-10-11 11:46:55.927+00', '2026-10-11 11:46:55.016+00', 'published', '2026-10-11 11:46:55.937+00', '2026-10-11 11:46:55.937+00', NULL, NULL, false, false),
	(6, 3, 'main', false, NULL, 2, 3, NULL, '2026-10-11 11:46:55.056+00', '2026-10-11 11:46:55.016+00', 'published', '2026-10-11 11:46:55.066+00', '2026-10-11 11:46:55.066+00', NULL, NULL, false, false),
	(32, 7, 'main', false, NULL, 4, NULL, NULL, '2026-10-11 11:46:56.488+00', '2026-10-11 11:46:55.394+00', 'published', '2026-10-11 11:46:56.5+00', '2026-10-11 11:46:56.5+00', NULL, NULL, true, false),
	(26, 4, 'main', false, 3, 1, 3, NULL, '2026-10-11 11:46:56.139+00', '2026-10-11 11:46:55.109+00', 'published', '2026-10-11 11:46:56.15+00', '2026-10-11 11:46:56.15+00', NULL, NULL, true, false),
	(7, 4, 'main', false, 3, 1, 3, NULL, '2026-10-11 11:46:55.109+00', '2026-10-11 11:46:55.109+00', 'published', '2026-10-11 11:46:55.114+00', '2026-10-11 11:46:55.114+00', NULL, NULL, false, false),
	(25, 4, 'main', false, 3, 1, 3, NULL, '2026-10-11 11:46:56.052+00', '2026-10-11 11:46:55.109+00', 'published', '2026-10-11 11:46:56.066+00', '2026-10-11 11:46:56.066+00', NULL, NULL, false, false),
	(8, 4, 'main', false, 3, 1, 3, NULL, '2026-10-11 11:46:55.154+00', '2026-10-11 11:46:55.109+00', 'published', '2026-10-11 11:46:55.164+00', '2026-10-11 11:46:55.164+00', NULL, NULL, false, false),
	(13, 7, 'main', false, NULL, 4, NULL, NULL, '2026-10-11 11:46:55.394+00', '2026-10-11 11:46:55.394+00', 'published', '2026-10-11 11:46:55.399+00', '2026-10-11 11:46:55.399+00', NULL, NULL, false, false),
	(28, 5, 'main', false, 3, 2, 2, NULL, '2026-10-11 11:46:56.26+00', '2026-10-11 11:46:55.206+00', 'published', '2026-10-11 11:46:56.274+00', '2026-10-11 11:46:56.274+00', NULL, NULL, true, false),
	(9, 5, 'main', false, 3, 2, 2, NULL, '2026-10-11 11:46:55.206+00', '2026-10-11 11:46:55.206+00', 'published', '2026-10-11 11:46:55.213+00', '2026-10-11 11:46:55.213+00', NULL, NULL, false, false),
	(27, 5, 'main', false, 3, 2, 2, NULL, '2026-10-11 11:46:56.198+00', '2026-10-11 11:46:55.206+00', 'published', '2026-10-11 11:46:56.21+00', '2026-10-11 11:46:56.21+00', NULL, NULL, false, false),
	(10, 5, 'main', false, 3, 2, 2, NULL, '2026-10-11 11:46:55.258+00', '2026-10-11 11:46:55.206+00', 'published', '2026-10-11 11:46:55.269+00', '2026-10-11 11:46:55.269+00', NULL, NULL, false, false),
	(30, 6, 'main', false, NULL, 3, NULL, NULL, '2026-10-11 11:46:56.371+00', '2026-10-11 11:46:55.309+00', 'published', '2026-10-11 11:46:56.384+00', '2026-10-11 11:46:56.384+00', NULL, NULL, true, false),
	(11, 6, 'main', false, NULL, 3, NULL, NULL, '2026-10-11 11:46:55.309+00', '2026-10-11 11:46:55.309+00', 'published', '2026-10-11 11:46:55.315+00', '2026-10-11 11:46:55.315+00', NULL, NULL, false, false),
	(29, 6, 'main', false, NULL, 3, NULL, NULL, '2026-10-11 11:46:56.318+00', '2026-10-11 11:46:55.309+00', 'published', '2026-10-11 11:46:56.33+00', '2026-10-11 11:46:56.33+00', NULL, NULL, false, false),
	(12, 6, 'main', false, NULL, 3, NULL, NULL, '2026-10-11 11:46:55.349+00', '2026-10-11 11:46:55.309+00', 'published', '2026-10-11 11:46:55.36+00', '2026-10-11 11:46:55.36+00', NULL, NULL, false, false),
	(31, 7, 'main', false, NULL, 4, NULL, NULL, '2026-10-11 11:46:56.43+00', '2026-10-11 11:46:55.394+00', 'published', '2026-10-11 11:46:56.443+00', '2026-10-11 11:46:56.443+00', NULL, NULL, false, false),
	(14, 7, 'main', false, NULL, 4, NULL, NULL, '2026-10-11 11:46:55.43+00', '2026-10-11 11:46:55.394+00', 'published', '2026-10-11 11:46:55.44+00', '2026-10-11 11:46:55.44+00', NULL, NULL, false, false),
	(34, 8, 'main', false, NULL, 9, NULL, true, '2026-10-11 11:46:56.589+00', '2026-10-11 11:46:55.473+00', 'published', '2026-10-11 11:46:56.599+00', '2026-10-11 11:46:56.599+00', NULL, NULL, true, false),
	(15, 8, 'main', false, NULL, 9, NULL, true, '2026-10-11 11:46:55.473+00', '2026-10-11 11:46:55.473+00', 'published', '2026-10-11 11:46:55.479+00', '2026-10-11 11:46:55.479+00', NULL, NULL, false, false),
	(33, 8, 'main', false, NULL, 9, NULL, true, '2026-10-11 11:46:56.54+00', '2026-10-11 11:46:55.473+00', 'published', '2026-10-11 11:46:56.55+00', '2026-10-11 11:46:56.55+00', NULL, NULL, false, false),
	(16, 8, 'main', false, NULL, 9, NULL, true, '2026-10-11 11:46:55.511+00', '2026-10-11 11:46:55.473+00', 'published', '2026-10-11 11:46:55.521+00', '2026-10-11 11:46:55.521+00', NULL, NULL, false, false),
	(36, 9, 'main', false, NULL, 10, NULL, true, '2026-10-11 11:46:56.686+00', '2026-10-11 11:46:55.555+00', 'published', '2026-10-11 11:46:56.695+00', '2026-10-11 11:46:56.695+00', NULL, NULL, true, false),
	(17, 9, 'main', false, NULL, 10, NULL, true, '2026-10-11 11:46:55.555+00', '2026-10-11 11:46:55.555+00', 'published', '2026-10-11 11:46:55.561+00', '2026-10-11 11:46:55.561+00', NULL, NULL, false, false),
	(35, 9, 'main', false, NULL, 10, NULL, true, '2026-10-11 11:46:56.637+00', '2026-10-11 11:46:55.555+00', 'published', '2026-10-11 11:46:56.647+00', '2026-10-11 11:46:56.647+00', NULL, NULL, false, false),
	(18, 9, 'main', false, NULL, 10, NULL, true, '2026-10-11 11:46:55.594+00', '2026-10-11 11:46:55.555+00', 'published', '2026-10-11 11:46:55.605+00', '2026-10-11 11:46:55.605+00', NULL, NULL, false, false);
INSERT INTO public._pages_v_blocks_accordion (_order, _parent_id, _path, _locale, id, heading, background, _uuid, block_name) VALUES
	(2, 25, 'version.layout', 'no', 1, 'Vanlige spørsmål', 'none', '6acb773086ea8069bc1d49f1', NULL),
	(2, 26, 'version.layout', 'no', 2, 'Vanlige spørsmål', 'none', '6acb773086ea8069bc1d49f1', NULL),
	(2, 26, 'version.layout', 'en', 3, 'Frequently asked questions', 'none', '6acb773086ea8069bc1d49f6', NULL);
INSERT INTO public._pages_v_blocks_accordion_items (_order, _parent_id, _locale, id, title, content, _uuid) VALUES
	(1, 1, 'no', 1, 'Hva koster det?', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Vi gir fast pris etter en første samtale.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d49ef'),
	(2, 1, 'no', 2, 'Hvor lang tid tar det?', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "De fleste oppdrag tar 4–8 uker.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d49f0'),
	(1, 2, 'no', 3, 'Hva koster det?', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Vi gir fast pris etter en første samtale.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d49ef'),
	(2, 2, 'no', 4, 'Hvor lang tid tar det?', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "De fleste oppdrag tar 4–8 uker.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d49f0'),
	(1, 3, 'en', 5, 'What does it cost?', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We give a fixed price after a first conversation.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d49f4'),
	(2, 3, 'en', 6, 'How long does it take?', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Most assignments take 4–8 weeks.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d49f5');
INSERT INTO public._pages_v_blocks_article_feed (_order, _parent_id, _path, _locale, id, heading, kind, "limit", paginate, background, _uuid, block_name) VALUES
	(3, 19, 'version.layout', 'no', 1, 'Siste nytt', 'all', 3, false, 'none', '6acb772f86ea8069bc1d49cb', NULL),
	(3, 20, 'version.layout', 'no', 2, 'Siste nytt', 'all', 3, false, 'none', '6acb772f86ea8069bc1d49cb', NULL),
	(3, 20, 'version.layout', 'en', 3, 'Latest news', 'all', 3, false, 'none', '6acb772f86ea8069bc1d49d5', NULL);
INSERT INTO public._pages_v_blocks_cards (_order, _parent_id, _path, _locale, id, heading, intro, columns, background, align, _uuid, block_name) VALUES
	(2, 19, 'version.layout', 'no', 1, 'Slik kan vi hjelpe', NULL, '3', 'none', 'center', '6acb772f86ea8069bc1d49ca', NULL),
	(2, 20, 'version.layout', 'no', 2, 'Slik kan vi hjelpe', NULL, '3', 'none', 'center', '6acb772f86ea8069bc1d49ca', NULL),
	(2, 20, 'version.layout', 'en', 3, 'How we can help', NULL, '3', 'none', 'center', '6acb772f86ea8069bc1d49d4', NULL);
INSERT INTO public._pages_v_blocks_cards_items (_order, _parent_id, _locale, id, title, text, image_id, link_type, link_new_tab, link_url, link_label, _uuid) VALUES
	(1, 1, 'no', 1, 'Rådgivning', 'Strategi og planer som holder.', 3, 'reference', NULL, NULL, 'Les mer', '6acb772f86ea8069bc1d49c7'),
	(2, 1, 'no', 2, 'Prosjekter', 'Vi leverer fra idé til drift.', 2, 'reference', NULL, NULL, 'Les mer', '6acb772f86ea8069bc1d49c8'),
	(3, 1, 'no', 3, 'Om oss', 'Et lite team med lang erfaring.', 4, 'reference', NULL, NULL, 'Les mer', '6acb772f86ea8069bc1d49c9'),
	(1, 2, 'no', 4, 'Rådgivning', 'Strategi og planer som holder.', 3, 'reference', NULL, NULL, 'Les mer', '6acb772f86ea8069bc1d49c7'),
	(2, 2, 'no', 5, 'Prosjekter', 'Vi leverer fra idé til drift.', 2, 'reference', NULL, NULL, 'Les mer', '6acb772f86ea8069bc1d49c8'),
	(3, 2, 'no', 6, 'Om oss', 'Et lite team med lang erfaring.', 4, 'reference', NULL, NULL, 'Les mer', '6acb772f86ea8069bc1d49c9'),
	(1, 3, 'en', 7, 'Advice', 'Strategy and plans that hold up.', 3, 'reference', NULL, NULL, 'Read more', '6acb772f86ea8069bc1d49d1'),
	(2, 3, 'en', 8, 'Projects', 'We deliver from idea to operations.', 2, 'reference', NULL, NULL, 'Read more', '6acb772f86ea8069bc1d49d2'),
	(3, 3, 'en', 9, 'About us', 'A small team with long experience.', 4, 'reference', NULL, NULL, 'Read more', '6acb772f86ea8069bc1d49d3');
INSERT INTO public._pages_v_blocks_child_pages (_order, _parent_id, _path, _locale, id, heading, intro, parent_id, depth, columns, background, _uuid, block_name) VALUES
	(2, 23, 'version.layout', 'no', 1, 'Tjenestene våre', NULL, 3, '1', '2', 'none', '6acb772f86ea8069bc1d49eb', NULL),
	(2, 24, 'version.layout', 'no', 2, 'Tjenestene våre', NULL, 3, '1', '2', 'none', '6acb772f86ea8069bc1d49eb', NULL),
	(2, 24, 'version.layout', 'en', 3, 'Our services', NULL, 3, '1', '2', 'none', '6acb772f86ea8069bc1d49ed', NULL);
INSERT INTO public._pages_v_blocks_content (_order, _parent_id, _path, _locale, id, width, align, background, rich_text, _uuid, block_name) VALUES
	(1, 23, 'version.layout', 'no', 1, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Det vi gjør", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Vi tilbyr rådgivning og prosjektgjennomføring.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb772f86ea8069bc1d49ea', NULL),
	(1, 24, 'version.layout', 'no', 2, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Det vi gjør", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Vi tilbyr rådgivning og prosjektgjennomføring.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb772f86ea8069bc1d49ea', NULL),
	(1, 24, 'version.layout', 'en', 3, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What we do", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We offer advice and project delivery.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb772f86ea8069bc1d49ec', NULL),
	(1, 25, 'version.layout', 'no', 4, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Vi hjelper deg å velge riktig retning.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d49ee', NULL),
	(1, 26, 'version.layout', 'no', 5, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Vi hjelper deg å velge riktig retning.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d49ee', NULL),
	(1, 26, 'version.layout', 'en', 6, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We help you choose the right direction.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d49f3', NULL),
	(1, 27, 'version.layout', 'no', 7, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Noen eksempler på hva vi har levert.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d49f8', NULL),
	(1, 28, 'version.layout', 'no', 8, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Noen eksempler på hva vi har levert.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d49f8', NULL),
	(1, 28, 'version.layout', 'en', 9, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Some examples of what we have delivered.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d49ff', NULL),
	(1, 31, 'version.layout', 'no', 10, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ring oss på +47 000 00 000 eller skriv til nettsted@example.com.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d4a0e', NULL),
	(1, 32, 'version.layout', 'no', 11, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ring oss på +47 000 00 000 eller skriv til nettsted@example.com.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d4a0e', NULL),
	(1, 32, 'version.layout', 'en', 12, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Call us on +47 000 00 000 or write to nettsted@example.com.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d4a11', NULL),
	(1, 33, 'version.layout', 'no', 13, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Personvern", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Eksempeltekst. Erstatt med virksomhetens egen personvernerklæring.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d4a14', NULL),
	(1, 34, 'version.layout', 'no', 14, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Personvern", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Eksempeltekst. Erstatt med virksomhetens egen personvernerklæring.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d4a14', NULL),
	(1, 34, 'version.layout', 'en', 15, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Privacy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Example text. Replace with the organisation''s own privacy notice.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d4a15', NULL),
	(1, 35, 'version.layout', 'no', 16, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Informasjonskapsler", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Vi bruker bare nødvendige informasjonskapsler, og statistikk når du samtykker.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d4a16', NULL),
	(1, 36, 'version.layout', 'no', 17, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Informasjonskapsler", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Vi bruker bare nødvendige informasjonskapsler, og statistikk når du samtykker.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d4a16', NULL),
	(1, 36, 'version.layout', 'en', 18, 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Cookies", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use only necessary cookies, and statistics when you consent.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', '6acb773086ea8069bc1d4a17', NULL);
INSERT INTO public._pages_v_blocks_cta (_order, _parent_id, _path, _locale, id, heading, text, background, align, _uuid, block_name) VALUES
	(4, 19, 'version.layout', 'no', 1, 'Klar for en prat?', 'Vi svarer innen én arbeidsdag.', 'tint', 'center', '6acb772f86ea8069bc1d49cd', NULL),
	(4, 20, 'version.layout', 'no', 2, 'Klar for en prat?', 'Vi svarer innen én arbeidsdag.', 'tint', 'center', '6acb772f86ea8069bc1d49cd', NULL),
	(4, 20, 'version.layout', 'en', 3, 'Ready to talk?', 'We reply within one working day.', 'tint', 'center', '6acb772f86ea8069bc1d49d7', NULL);
INSERT INTO public._pages_v_blocks_cta_links (_order, _parent_id, _locale, id, link_type, link_new_tab, link_url, link_label, link_appearance, _uuid) VALUES
	(1, 1, 'no', 1, 'reference', NULL, NULL, 'Kontakt oss', 'primary', '6acb772f86ea8069bc1d49cc'),
	(1, 2, 'no', 2, 'reference', NULL, NULL, 'Kontakt oss', 'primary', '6acb772f86ea8069bc1d49cc'),
	(1, 3, 'en', 3, 'reference', NULL, NULL, 'Contact us', 'primary', '6acb772f86ea8069bc1d49d6');
INSERT INTO public._pages_v_blocks_documents (_order, _parent_id, _path, _locale, id, heading, background, _uuid, block_name) VALUES
	(3, 31, 'version.layout', 'no', 1, 'Dokumenter', 'none', '6acb773086ea8069bc1d4a10', NULL),
	(3, 32, 'version.layout', 'no', 2, 'Dokumenter', 'none', '6acb773086ea8069bc1d4a10', NULL),
	(3, 32, 'version.layout', 'en', 3, 'Documents', 'none', '6acb773086ea8069bc1d4a13', NULL);
INSERT INTO public._pages_v_blocks_embed (_order, _parent_id, _path, _locale, id, heading, provider, url, title, height, _uuid, block_name) VALUES
	(2, 31, 'version.layout', 'no', 1, 'Finn oss', 'google-maps', 'https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d2000!2d18.95!3d69.65!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sno!2sno', 'Kart over Tromsø', 400, '6acb773086ea8069bc1d4a0f', NULL),
	(2, 32, 'version.layout', 'no', 2, 'Finn oss', 'google-maps', 'https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d2000!2d18.95!3d69.65!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sno!2sno', 'Kart over Tromsø', 400, '6acb773086ea8069bc1d4a0f', NULL),
	(2, 32, 'version.layout', 'en', 3, 'Find us', 'google-maps', 'https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d2000!2d18.95!3d69.65!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sno!2sno', 'Map of Tromsø', 400, '6acb773086ea8069bc1d4a12', NULL);
INSERT INTO public._pages_v_blocks_facts (_order, _parent_id, _path, _locale, id, heading, background, _uuid, block_name) VALUES
	(2, 29, 'version.layout', 'no', 1, 'Fakta', 'none', '6acb773086ea8069bc1d4a09', NULL),
	(2, 30, 'version.layout', 'no', 2, 'Fakta', 'none', '6acb773086ea8069bc1d4a09', NULL),
	(2, 30, 'version.layout', 'en', 3, 'Facts', 'none', '6acb773086ea8069bc1d4a0d', NULL);
INSERT INTO public._pages_v_blocks_facts_items (_order, _parent_id, _locale, id, label, value, _uuid) VALUES
	(1, 1, 'no', 1, 'Ansatte', '2', '6acb773086ea8069bc1d4a07'),
	(2, 1, 'no', 2, 'Kontorer', 'Tromsø og Oslo', '6acb773086ea8069bc1d4a08'),
	(1, 2, 'no', 3, 'Ansatte', '2', '6acb773086ea8069bc1d4a07'),
	(2, 2, 'no', 4, 'Kontorer', 'Tromsø og Oslo', '6acb773086ea8069bc1d4a08'),
	(1, 3, 'en', 5, 'Employees', '2', '6acb773086ea8069bc1d4a0b'),
	(2, 3, 'en', 6, 'Offices', 'Tromsø and Oslo', '6acb773086ea8069bc1d4a0c');
INSERT INTO public._pages_v_blocks_full_image (_order, _parent_id, _path, _locale, id, image_id, caption, size, _uuid, block_name) VALUES
	(3, 27, 'version.layout', 'no', 1, 1, 'Eksempelbilde', 'wide', '6acb773086ea8069bc1d49fd', NULL),
	(3, 28, 'version.layout', 'no', 2, 1, 'Eksempelbilde', 'wide', '6acb773086ea8069bc1d49fd', NULL),
	(3, 28, 'version.layout', 'en', 3, 1, 'Example image', 'wide', '6acb773086ea8069bc1d4a04', NULL);
INSERT INTO public._pages_v_blocks_hero (_order, _parent_id, _path, _locale, id, variant, eyebrow, eyebrow_highlight, heading, text, media_id, align, _uuid, block_name) VALUES
	(1, 19, 'version.layout', 'no', 1, 'image', 'Rådgivning', NULL, 'Vi hjelper virksomheter å lykkes digitalt', 'Nordlys Demo er et eksempelnettsted for Hosait Site Kit.', 1, 'left', '6acb772f86ea8069bc1d49c6', NULL),
	(1, 20, 'version.layout', 'no', 2, 'image', 'Rådgivning', NULL, 'Vi hjelper virksomheter å lykkes digitalt', 'Nordlys Demo er et eksempelnettsted for Hosait Site Kit.', 1, 'left', '6acb772f86ea8069bc1d49c6', NULL),
	(1, 20, 'version.layout', 'en', 3, 'image', 'Advisory', NULL, 'We help businesses succeed online', 'Nordlys Demo is an example website for Hosait Site Kit.', 1, 'left', '6acb772f86ea8069bc1d49d0', NULL);
INSERT INTO public._pages_v_blocks_hero_links (_order, _parent_id, _locale, id, link_type, link_new_tab, link_url, link_label, link_appearance, _uuid) VALUES
	(1, 1, 'no', 1, 'reference', NULL, NULL, 'Våre tjenester', 'primary', '6acb772f86ea8069bc1d49c4'),
	(2, 1, 'no', 2, 'reference', NULL, NULL, 'Kontakt oss', 'primary', '6acb772f86ea8069bc1d49c5'),
	(1, 2, 'no', 3, 'reference', NULL, NULL, 'Våre tjenester', 'primary', '6acb772f86ea8069bc1d49c4'),
	(2, 2, 'no', 4, 'reference', NULL, NULL, 'Kontakt oss', 'primary', '6acb772f86ea8069bc1d49c5'),
	(1, 3, 'en', 5, 'reference', NULL, NULL, 'Our services', 'primary', '6acb772f86ea8069bc1d49ce'),
	(2, 3, 'en', 6, 'reference', NULL, NULL, 'Contact us', 'primary', '6acb772f86ea8069bc1d49cf');
INSERT INTO public._pages_v_blocks_image_grid (_order, _parent_id, _path, _locale, id, heading, columns, background, _uuid, block_name) VALUES
	(2, 27, 'version.layout', 'no', 1, 'Utvalgte prosjekter', '3', 'none', '6acb773086ea8069bc1d49fc', NULL),
	(2, 28, 'version.layout', 'no', 2, 'Utvalgte prosjekter', '3', 'none', '6acb773086ea8069bc1d49fc', NULL),
	(2, 28, 'version.layout', 'en', 3, 'Selected projects', '3', 'none', '6acb773086ea8069bc1d4a03', NULL);
INSERT INTO public._pages_v_blocks_image_grid_images (_order, _parent_id, _locale, id, image_id, caption, _uuid) VALUES
	(1, 1, 'no', 1, 4, 'Fjord', '6acb773086ea8069bc1d49f9'),
	(2, 1, 'no', 2, 5, 'Kyst', '6acb773086ea8069bc1d49fa'),
	(3, 1, 'no', 3, 2, 'Kontor', '6acb773086ea8069bc1d49fb'),
	(1, 2, 'no', 4, 4, 'Fjord', '6acb773086ea8069bc1d49f9'),
	(2, 2, 'no', 5, 5, 'Kyst', '6acb773086ea8069bc1d49fa'),
	(3, 2, 'no', 6, 2, 'Kontor', '6acb773086ea8069bc1d49fb'),
	(1, 3, 'en', 7, 4, 'Fjord', '6acb773086ea8069bc1d4a00'),
	(2, 3, 'en', 8, 5, 'Coast', '6acb773086ea8069bc1d4a01'),
	(3, 3, 'en', 9, 2, 'Office', '6acb773086ea8069bc1d4a02');
INSERT INTO public._pages_v_blocks_people (_order, _parent_id, _path, _locale, id, heading, layout, background, _uuid, block_name) VALUES
	(1, 29, 'version.layout', 'no', 1, 'Menneskene bak', 'grid', 'none', '6acb773086ea8069bc1d4a06', NULL),
	(1, 30, 'version.layout', 'no', 2, 'Menneskene bak', 'grid', 'none', '6acb773086ea8069bc1d4a06', NULL),
	(1, 30, 'version.layout', 'en', 3, 'The people behind it', 'grid', 'none', '6acb773086ea8069bc1d4a0a', NULL);
INSERT INTO public._pages_v_blocks_quote (_order, _parent_id, _path, _locale, id, quote, author, role, image_id, background, align, _uuid, block_name) VALUES
	(4, 27, 'version.layout', 'no', 1, 'De leverte til avtalt tid og pris.', 'Eksempel Kunde AS', 'Kunde', NULL, 'none', 'center', '6acb773086ea8069bc1d49fe', NULL),
	(4, 28, 'version.layout', 'no', 2, 'De leverte til avtalt tid og pris.', 'Eksempel Kunde AS', 'Kunde', NULL, 'none', 'center', '6acb773086ea8069bc1d49fe', NULL),
	(4, 28, 'version.layout', 'en', 3, 'They delivered on time and on budget.', 'Eksempel Kunde AS', 'Client', NULL, 'none', 'center', '6acb773086ea8069bc1d4a05', NULL);
INSERT INTO public._pages_v_blocks_stats (_order, _parent_id, _path, _locale, id, heading, intro, background, align, _uuid, block_name) VALUES
	(2, 21, 'version.layout', 'no', 1, 'I tall', NULL, 'muted', 'left', '6acb772f86ea8069bc1d49dc', NULL),
	(2, 22, 'version.layout', 'no', 2, 'I tall', NULL, 'muted', 'left', '6acb772f86ea8069bc1d49dc', NULL),
	(2, 22, 'version.layout', 'en', 3, 'In numbers', NULL, 'muted', 'left', '6acb772f86ea8069bc1d49e5', NULL);
INSERT INTO public._pages_v_blocks_stats_items (_order, _parent_id, _locale, id, value, label, _uuid) VALUES
	(1, 1, 'no', 1, '15', 'år med erfaring', '6acb772f86ea8069bc1d49d9'),
	(2, 1, 'no', 2, '120', 'prosjekter', '6acb772f86ea8069bc1d49da'),
	(3, 1, 'no', 3, '2', 'kontorer', '6acb772f86ea8069bc1d49db'),
	(1, 2, 'no', 4, '15', 'år med erfaring', '6acb772f86ea8069bc1d49d9'),
	(2, 2, 'no', 5, '120', 'prosjekter', '6acb772f86ea8069bc1d49da'),
	(3, 2, 'no', 6, '2', 'kontorer', '6acb772f86ea8069bc1d49db'),
	(1, 3, 'en', 7, '15', 'years of experience', '6acb772f86ea8069bc1d49e2'),
	(2, 3, 'en', 8, '120', 'projects', '6acb772f86ea8069bc1d49e3'),
	(3, 3, 'en', 9, '2', 'offices', '6acb772f86ea8069bc1d49e4');
INSERT INTO public._pages_v_blocks_text_image (_order, _parent_id, _path, _locale, id, eyebrow, heading, rich_text, image_id, image_position, layout, background, _uuid, block_name) VALUES
	(1, 21, 'version.layout', 'no', 1, NULL, 'Hvem vi er', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Nordlys Demo er et fiktivt firma laget for å vise hva Site Kit kan.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Alt innhold her er eksempler.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', 2, 'right', 'split', 'none', '6acb772f86ea8069bc1d49d8', NULL),
	(1, 22, 'version.layout', 'no', 2, NULL, 'Hvem vi er', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Nordlys Demo er et fiktivt firma laget for å vise hva Site Kit kan.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Alt innhold her er eksempler.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', 2, 'right', 'split', 'none', '6acb772f86ea8069bc1d49d8', NULL),
	(1, 22, 'version.layout', 'en', 3, NULL, 'Who we are', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Nordlys Demo is a fictional company made to show what Site Kit can do.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "All content here is an example.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', 2, 'right', 'split', 'none', '6acb772f86ea8069bc1d49e1', NULL);
INSERT INTO public._pages_v_blocks_timeline (_order, _parent_id, _path, _locale, id, heading, background, _uuid, block_name) VALUES
	(3, 21, 'version.layout', 'no', 1, 'Historien vår', 'none', '6acb772f86ea8069bc1d49e0', NULL),
	(3, 22, 'version.layout', 'no', 2, 'Historien vår', 'none', '6acb772f86ea8069bc1d49e0', NULL),
	(3, 22, 'version.layout', 'en', 3, 'Our story', 'none', '6acb772f86ea8069bc1d49e9', NULL);
INSERT INTO public._pages_v_blocks_timeline_items (_order, _parent_id, _locale, id, year, title, text, image_id, _uuid) VALUES
	(1, 1, 'no', 1, '2011', 'Oppstart', 'Startet i Tromsø.', NULL, '6acb772f86ea8069bc1d49dd'),
	(2, 1, 'no', 2, '2018', 'Nytt kontor', 'Åpnet kontor i Oslo.', NULL, '6acb772f86ea8069bc1d49de'),
	(3, 1, 'no', 3, '2026', 'Hosait', 'Flyttet nettstedet til Hosait.', 5, '6acb772f86ea8069bc1d49df'),
	(1, 2, 'no', 4, '2011', 'Oppstart', 'Startet i Tromsø.', NULL, '6acb772f86ea8069bc1d49dd'),
	(2, 2, 'no', 5, '2018', 'Nytt kontor', 'Åpnet kontor i Oslo.', NULL, '6acb772f86ea8069bc1d49de'),
	(3, 2, 'no', 6, '2026', 'Hosait', 'Flyttet nettstedet til Hosait.', 5, '6acb772f86ea8069bc1d49df'),
	(1, 3, 'en', 7, '2011', 'Founded', 'Started in Tromsø.', NULL, '6acb772f86ea8069bc1d49e6'),
	(2, 3, 'en', 8, '2018', 'New office', 'Opened an office in Oslo.', NULL, '6acb772f86ea8069bc1d49e7'),
	(3, 3, 'en', 9, '2026', 'Hosait', 'Moved the website to Hosait.', 5, '6acb772f86ea8069bc1d49e8');
INSERT INTO public._pages_v_blocks_video (_order, _parent_id, _path, _locale, id, heading, url, file_id, poster_id, background, _uuid, block_name) VALUES
	(3, 25, 'version.layout', 'no', 1, 'Film: Big Buck Bunny (Blender Foundation, CC BY)', 'https://www.youtube.com/watch?v=aqz-KE-bpKQ', NULL, 5, 'none', '6acb773086ea8069bc1d49f2', NULL),
	(3, 26, 'version.layout', 'no', 2, 'Film: Big Buck Bunny (Blender Foundation, CC BY)', 'https://www.youtube.com/watch?v=aqz-KE-bpKQ', NULL, 5, 'none', '6acb773086ea8069bc1d49f2', NULL),
	(3, 26, 'version.layout', 'en', 3, 'Film: Big Buck Bunny (Blender Foundation, CC BY)', 'https://www.youtube.com/watch?v=aqz-KE-bpKQ', NULL, 5, 'none', '6acb773086ea8069bc1d49f7', NULL);
INSERT INTO public._pages_v_locales (version_title, version_meta_title, version_meta_image_id, version_meta_description, version_meta_noindex, version_slug, version_path, version_path_override, version_summary, id, _locale, _parent_id) VALUES
	('Forside', NULL, NULL, NULL, NULL, '', '', NULL, NULL, 1, 'no', 1),
	('Forside', NULL, NULL, NULL, NULL, '', '', NULL, NULL, 2, 'no', 2),
	('Home', NULL, NULL, NULL, NULL, '', '', NULL, NULL, 3, 'en', 2),
	('Om oss', NULL, NULL, NULL, NULL, 'om-oss', 'om-oss', NULL, 'Hvem vi er og hvor vi kommer fra.', 4, 'no', 3),
	('Om oss', NULL, NULL, NULL, NULL, 'om-oss', 'om-oss', NULL, 'Hvem vi er og hvor vi kommer fra.', 5, 'no', 4),
	('About us', NULL, NULL, NULL, NULL, 'about', 'about', NULL, 'Who we are and where we come from.', 6, 'en', 4),
	('Tjenester', NULL, NULL, NULL, NULL, 'tjenester', 'tjenester', NULL, 'Rådgivning og prosjekter.', 7, 'no', 5),
	('Tjenester', NULL, NULL, NULL, NULL, 'tjenester', 'tjenester', NULL, 'Rådgivning og prosjekter.', 8, 'no', 6),
	('Services', NULL, NULL, NULL, NULL, 'services', 'services', NULL, 'Advice and projects.', 9, 'en', 6),
	('Rådgivning', NULL, NULL, NULL, NULL, 'radgivning', 'tjenester/radgivning', NULL, 'Strategi og planer.', 10, 'no', 7),
	('Rådgivning', NULL, NULL, NULL, NULL, 'radgivning', 'tjenester/radgivning', NULL, 'Strategi og planer.', 11, 'no', 8),
	('Advice', NULL, NULL, NULL, NULL, 'advice', 'services/advice', NULL, 'Strategy and plans.', 12, 'en', 8),
	('Prosjekter', NULL, NULL, NULL, NULL, 'prosjekter', 'tjenester/prosjekter', NULL, 'Fra idé til drift.', 13, 'no', 9),
	('Prosjekter', NULL, NULL, NULL, NULL, 'prosjekter', 'tjenester/prosjekter', NULL, 'Fra idé til drift.', 14, 'no', 10),
	('Projects', NULL, NULL, NULL, NULL, 'projects', 'services/projects', NULL, 'From idea to operations.', 15, 'en', 10),
	('Folk', NULL, NULL, NULL, NULL, 'folk', 'folk', NULL, NULL, 16, 'no', 11),
	('Folk', NULL, NULL, NULL, NULL, 'folk', 'folk', NULL, NULL, 17, 'no', 12),
	('People', NULL, NULL, NULL, NULL, 'people', 'people', NULL, NULL, 18, 'en', 12),
	('Kontakt', NULL, NULL, NULL, NULL, 'kontakt', 'kontakt', NULL, NULL, 19, 'no', 13),
	('Kontakt', NULL, NULL, NULL, NULL, 'kontakt', 'kontakt', NULL, NULL, 20, 'no', 14),
	('Contact', NULL, NULL, NULL, NULL, 'contact', 'contact', NULL, NULL, 21, 'en', 14),
	('Personvern', NULL, NULL, NULL, NULL, 'personvern', 'personvern', NULL, NULL, 22, 'no', 15),
	('Personvern', NULL, NULL, NULL, NULL, 'personvern', 'personvern', NULL, NULL, 23, 'no', 16),
	('Privacy', NULL, NULL, NULL, NULL, 'privacy', 'privacy', NULL, NULL, 24, 'en', 16),
	('Informasjonskapsler', NULL, NULL, NULL, NULL, 'informasjonskapsler', 'informasjonskapsler', NULL, NULL, 25, 'no', 17),
	('Informasjonskapsler', NULL, NULL, NULL, NULL, 'informasjonskapsler', 'informasjonskapsler', NULL, NULL, 26, 'no', 18),
	('Cookies', NULL, NULL, NULL, NULL, 'cookies', 'cookies', NULL, NULL, 27, 'en', 18),
	('Forside', NULL, NULL, NULL, NULL, '', '', NULL, NULL, 28, 'no', 19),
	('Home', NULL, NULL, NULL, NULL, '', '', NULL, NULL, 29, 'en', 19),
	('Forside', NULL, NULL, NULL, NULL, '', '', NULL, NULL, 30, 'no', 20),
	('Home', NULL, NULL, NULL, NULL, '', '', NULL, NULL, 31, 'en', 20),
	('Om oss', NULL, NULL, NULL, NULL, 'om-oss', 'om-oss', NULL, 'Hvem vi er og hvor vi kommer fra.', 32, 'no', 21),
	('About us', NULL, NULL, NULL, NULL, 'about', 'about', NULL, 'Who we are and where we come from.', 33, 'en', 21),
	('Om oss', NULL, NULL, NULL, NULL, 'om-oss', 'om-oss', NULL, 'Hvem vi er og hvor vi kommer fra.', 34, 'no', 22),
	('About us', NULL, NULL, NULL, NULL, 'about', 'about', NULL, 'Who we are and where we come from.', 35, 'en', 22),
	('Tjenester', NULL, NULL, NULL, NULL, 'tjenester', 'tjenester', NULL, 'Rådgivning og prosjekter.', 36, 'no', 23),
	('Services', NULL, NULL, NULL, NULL, 'services', 'services', NULL, 'Advice and projects.', 37, 'en', 23),
	('Tjenester', NULL, NULL, NULL, NULL, 'tjenester', 'tjenester', NULL, 'Rådgivning og prosjekter.', 38, 'no', 24),
	('Services', NULL, NULL, NULL, NULL, 'services', 'services', NULL, 'Advice and projects.', 39, 'en', 24),
	('Rådgivning', NULL, NULL, NULL, NULL, 'radgivning', 'tjenester/radgivning', NULL, 'Strategi og planer.', 40, 'no', 25),
	('Advice', NULL, NULL, NULL, NULL, 'advice', 'services/advice', NULL, 'Strategy and plans.', 41, 'en', 25),
	('Rådgivning', NULL, NULL, NULL, NULL, 'radgivning', 'tjenester/radgivning', NULL, 'Strategi og planer.', 42, 'no', 26),
	('Advice', NULL, NULL, NULL, NULL, 'advice', 'services/advice', NULL, 'Strategy and plans.', 43, 'en', 26),
	('Prosjekter', NULL, NULL, NULL, NULL, 'prosjekter', 'tjenester/prosjekter', NULL, 'Fra idé til drift.', 44, 'no', 27),
	('Projects', NULL, NULL, NULL, NULL, 'projects', 'services/projects', NULL, 'From idea to operations.', 45, 'en', 27),
	('Prosjekter', NULL, NULL, NULL, NULL, 'prosjekter', 'tjenester/prosjekter', NULL, 'Fra idé til drift.', 46, 'no', 28),
	('Projects', NULL, NULL, NULL, NULL, 'projects', 'services/projects', NULL, 'From idea to operations.', 47, 'en', 28),
	('Folk', NULL, NULL, NULL, NULL, 'folk', 'folk', NULL, NULL, 48, 'no', 29),
	('People', NULL, NULL, NULL, NULL, 'people', 'people', NULL, NULL, 49, 'en', 29),
	('Folk', NULL, NULL, NULL, NULL, 'folk', 'folk', NULL, NULL, 50, 'no', 30),
	('People', NULL, NULL, NULL, NULL, 'people', 'people', NULL, NULL, 51, 'en', 30),
	('Kontakt', NULL, NULL, NULL, NULL, 'kontakt', 'kontakt', NULL, NULL, 52, 'no', 31),
	('Contact', NULL, NULL, NULL, NULL, 'contact', 'contact', NULL, NULL, 53, 'en', 31),
	('Kontakt', NULL, NULL, NULL, NULL, 'kontakt', 'kontakt', NULL, NULL, 54, 'no', 32),
	('Contact', NULL, NULL, NULL, NULL, 'contact', 'contact', NULL, NULL, 55, 'en', 32),
	('Personvern', NULL, NULL, NULL, NULL, 'personvern', 'personvern', NULL, NULL, 56, 'no', 33),
	('Privacy', NULL, NULL, NULL, NULL, 'privacy', 'privacy', NULL, NULL, 57, 'en', 33),
	('Personvern', NULL, NULL, NULL, NULL, 'personvern', 'personvern', NULL, NULL, 58, 'no', 34),
	('Privacy', NULL, NULL, NULL, NULL, 'privacy', 'privacy', NULL, NULL, 59, 'en', 34),
	('Informasjonskapsler', NULL, NULL, NULL, NULL, 'informasjonskapsler', 'informasjonskapsler', NULL, NULL, 60, 'no', 35),
	('Cookies', NULL, NULL, NULL, NULL, 'cookies', 'cookies', NULL, NULL, 61, 'en', 35),
	('Informasjonskapsler', NULL, NULL, NULL, NULL, 'informasjonskapsler', 'informasjonskapsler', NULL, NULL, 62, 'no', 36),
	('Cookies', NULL, NULL, NULL, NULL, 'cookies', 'cookies', NULL, NULL, 63, 'en', 36);
INSERT INTO public.documents (id, doc_type, language, prefix, _objectkey, folder_id, updated_at, created_at, url, thumbnail_u_r_l, filename, mime_type, filesize, width, height, focal_x, focal_y) VALUES
	(1, 'manual', 'no', 'public/documents', NULL, NULL, '2026-10-11 11:46:54.804+00', '2026-10-11 11:46:54.737+00', '/api/documents/file/brukerveiledning.pdf', NULL, 'brukerveiledning.pdf', 'application/pdf', 682, NULL, NULL, NULL, NULL);
INSERT INTO public.people (id, name, email, phone, image_id, site, has_left, updated_at, created_at) VALUES
	(1, 'Kari Nordmann', 'kari@example.com', '+47 000 00 001', 6, 'main', false, '2026-10-11 11:46:54.694+00', '2026-10-11 11:46:54.679+00'),
	(2, 'Ola Nordmann', 'ola@example.com', '+47 000 00 002', 7, 'main', false, '2026-10-11 11:46:54.72+00', '2026-10-11 11:46:54.71+00');
INSERT INTO public._pages_v_rels (id, "order", parent_id, path, locale, pages_id, articles_id, people_id, documents_id) VALUES
	(1, NULL, 19, 'version.layout.0.links.0.link.reference', 'no', 3, NULL, NULL, NULL),
	(2, NULL, 19, 'version.layout.0.links.1.link.reference', 'no', 7, NULL, NULL, NULL),
	(3, NULL, 19, 'version.layout.1.items.0.link.reference', 'no', 4, NULL, NULL, NULL),
	(4, NULL, 19, 'version.layout.1.items.1.link.reference', 'no', 5, NULL, NULL, NULL),
	(5, NULL, 19, 'version.layout.1.items.2.link.reference', 'no', 2, NULL, NULL, NULL),
	(6, NULL, 19, 'version.layout.3.links.0.link.reference', 'no', 7, NULL, NULL, NULL),
	(7, NULL, 20, 'version.layout.0.links.0.link.reference', 'no', 3, NULL, NULL, NULL),
	(8, NULL, 20, 'version.layout.0.links.1.link.reference', 'no', 7, NULL, NULL, NULL),
	(9, NULL, 20, 'version.layout.1.items.0.link.reference', 'no', 4, NULL, NULL, NULL),
	(10, NULL, 20, 'version.layout.1.items.1.link.reference', 'no', 5, NULL, NULL, NULL),
	(11, NULL, 20, 'version.layout.1.items.2.link.reference', 'no', 2, NULL, NULL, NULL),
	(12, NULL, 20, 'version.layout.3.links.0.link.reference', 'no', 7, NULL, NULL, NULL),
	(13, NULL, 20, 'version.layout.0.links.0.link.reference', 'en', 3, NULL, NULL, NULL),
	(14, NULL, 20, 'version.layout.0.links.1.link.reference', 'en', 7, NULL, NULL, NULL),
	(15, NULL, 20, 'version.layout.1.items.0.link.reference', 'en', 4, NULL, NULL, NULL),
	(16, NULL, 20, 'version.layout.1.items.1.link.reference', 'en', 5, NULL, NULL, NULL),
	(17, NULL, 20, 'version.layout.1.items.2.link.reference', 'en', 2, NULL, NULL, NULL),
	(18, NULL, 20, 'version.layout.3.links.0.link.reference', 'en', 7, NULL, NULL, NULL),
	(19, 1, 29, 'version.layout.0.people', 'no', NULL, NULL, 1, NULL),
	(20, 2, 29, 'version.layout.0.people', 'no', NULL, NULL, 2, NULL),
	(21, 1, 30, 'version.layout.0.people', 'no', NULL, NULL, 1, NULL),
	(22, 2, 30, 'version.layout.0.people', 'no', NULL, NULL, 2, NULL),
	(23, 1, 30, 'version.layout.0.people', 'en', NULL, NULL, 1, NULL),
	(24, 2, 30, 'version.layout.0.people', 'en', NULL, NULL, 2, NULL),
	(25, 1, 31, 'version.layout.2.documents', 'no', NULL, NULL, NULL, 1),
	(26, 1, 32, 'version.layout.2.documents', 'no', NULL, NULL, NULL, 1),
	(27, 1, 32, 'version.layout.2.documents', 'en', NULL, NULL, NULL, 1);
INSERT INTO public.articles_locales (title, lead, content, meta_title, meta_image_id, meta_description, meta_noindex, slug, id, _locale, _parent_id) VALUES
	('Nytt nettsted på Hosait', 'Vi har flyttet nettstedet.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Nettstedet kjører nå på Hosait Site Kit.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'nytt-nettsted-pa-hosait', 2, 'no', 1),
	('New website on Hosait', 'We have moved our website.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The website now runs on Hosait Site Kit.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'new-website-on-hosait', 3, 'en', 1),
	('Nytt kontor i Oslo', 'Vi har åpnet kontor i Oslo.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Velkommen innom.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'nytt-kontor-i-oslo', 5, 'no', 2),
	('New office in Oslo', 'We have opened an office in Oslo.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Drop by.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'new-office-in-oslo', 6, 'en', 2),
	('Tre råd om digital strategi', 'Kort fortalt.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "1. Start smått", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Velg ett mål.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "2. Mål", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Følg med på tallene.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "3. Juster", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Gjør små endringer ofte.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'tre-rad-om-digital-strategi', 8, 'no', 3),
	('Three tips on digital strategy', 'In short.', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "1. Start small", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Pick one goal.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "2. Measure", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Watch the numbers.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "3. Adjust", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Make small changes often.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL, NULL, NULL, NULL, 'three-tips-on-digital-strategy', 9, 'en', 3);
INSERT INTO public.documents_locales (title, description, id, _locale, _parent_id) VALUES
	('Brukerveiledning', 'Eksempeldokument.', 2, 'no', 1),
	('User guide', 'Example document.', 3, 'en', 1);
INSERT INTO public.documents_sites ("order", parent_id, value, id) VALUES
	(1, 1, 'main', 2);
INSERT INTO public.media_locales (alt, id, _locale, _parent_id) VALUES
	('Abstrakt nordlys over en fjord', 2, 'no', 1),
	('Abstract northern lights over a fjord', 3, 'en', 1),
	('Lyst kontorlandskap', 5, 'no', 2),
	('Bright open-plan office', 6, 'en', 2),
	('Arbeidsmøte rundt et bord', 8, 'no', 3),
	('Working session around a table', 9, 'en', 3),
	('Fjordlandskap i blått', 11, 'no', 4),
	('Fjord landscape in blue', 12, 'en', 4),
	('Kystlinje i morgenlys', 14, 'no', 5),
	('Coastline in morning light', 15, 'en', 5),
	('Portrett av Kari Nordmann', 17, 'no', 6),
	('Portrait of Kari Nordmann', 18, 'en', 6),
	('Portrett av Ola Nordmann', 20, 'no', 7),
	('Portrait of Ola Nordmann', 21, 'en', 7),
	('Illustrasjon til nyhet', 23, 'no', 8),
	('News illustration', 24, 'en', 8);
INSERT INTO public.pages_blocks_accordion (_order, _parent_id, _path, _locale, id, heading, background, block_name) VALUES
	(2, 4, 'layout', 'no', '6acb773086ea8069bc1d49f1', 'Vanlige spørsmål', 'none', NULL),
	(2, 4, 'layout', 'en', '6acb773086ea8069bc1d49f6', 'Frequently asked questions', 'none', NULL);
INSERT INTO public.pages_blocks_accordion_items (_order, _parent_id, _locale, id, title, content) VALUES
	(1, '6acb773086ea8069bc1d49f1', 'no', '6acb773086ea8069bc1d49ef', 'Hva koster det?', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Vi gir fast pris etter en første samtale.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}'),
	(2, '6acb773086ea8069bc1d49f1', 'no', '6acb773086ea8069bc1d49f0', 'Hvor lang tid tar det?', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "De fleste oppdrag tar 4–8 uker.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}'),
	(1, '6acb773086ea8069bc1d49f6', 'en', '6acb773086ea8069bc1d49f4', 'What does it cost?', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We give a fixed price after a first conversation.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}'),
	(2, '6acb773086ea8069bc1d49f6', 'en', '6acb773086ea8069bc1d49f5', 'How long does it take?', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Most assignments take 4–8 weeks.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}');
INSERT INTO public.pages_blocks_article_feed (_order, _parent_id, _path, _locale, id, heading, kind, "limit", paginate, background, block_name) VALUES
	(3, 1, 'layout', 'no', '6acb772f86ea8069bc1d49cb', 'Siste nytt', 'all', 3, false, 'none', NULL),
	(3, 1, 'layout', 'en', '6acb772f86ea8069bc1d49d5', 'Latest news', 'all', 3, false, 'none', NULL);
INSERT INTO public.pages_blocks_cards (_order, _parent_id, _path, _locale, id, heading, intro, columns, background, align, block_name) VALUES
	(2, 1, 'layout', 'no', '6acb772f86ea8069bc1d49ca', 'Slik kan vi hjelpe', NULL, '3', 'none', 'center', NULL),
	(2, 1, 'layout', 'en', '6acb772f86ea8069bc1d49d4', 'How we can help', NULL, '3', 'none', 'center', NULL);
INSERT INTO public.pages_blocks_cards_items (_order, _parent_id, _locale, id, title, text, image_id, link_type, link_new_tab, link_url, link_label) VALUES
	(1, '6acb772f86ea8069bc1d49ca', 'no', '6acb772f86ea8069bc1d49c7', 'Rådgivning', 'Strategi og planer som holder.', 3, 'reference', NULL, NULL, 'Les mer'),
	(2, '6acb772f86ea8069bc1d49ca', 'no', '6acb772f86ea8069bc1d49c8', 'Prosjekter', 'Vi leverer fra idé til drift.', 2, 'reference', NULL, NULL, 'Les mer'),
	(3, '6acb772f86ea8069bc1d49ca', 'no', '6acb772f86ea8069bc1d49c9', 'Om oss', 'Et lite team med lang erfaring.', 4, 'reference', NULL, NULL, 'Les mer'),
	(1, '6acb772f86ea8069bc1d49d4', 'en', '6acb772f86ea8069bc1d49d1', 'Advice', 'Strategy and plans that hold up.', 3, 'reference', NULL, NULL, 'Read more'),
	(2, '6acb772f86ea8069bc1d49d4', 'en', '6acb772f86ea8069bc1d49d2', 'Projects', 'We deliver from idea to operations.', 2, 'reference', NULL, NULL, 'Read more'),
	(3, '6acb772f86ea8069bc1d49d4', 'en', '6acb772f86ea8069bc1d49d3', 'About us', 'A small team with long experience.', 4, 'reference', NULL, NULL, 'Read more');
INSERT INTO public.pages_blocks_child_pages (_order, _parent_id, _path, _locale, id, heading, intro, parent_id, depth, columns, background, block_name) VALUES
	(2, 3, 'layout', 'no', '6acb772f86ea8069bc1d49eb', 'Tjenestene våre', NULL, 3, '1', '2', 'none', NULL),
	(2, 3, 'layout', 'en', '6acb772f86ea8069bc1d49ed', 'Our services', NULL, 3, '1', '2', 'none', NULL);
INSERT INTO public.pages_blocks_content (_order, _parent_id, _path, _locale, id, width, align, background, rich_text, block_name) VALUES
	(1, 3, 'layout', 'no', '6acb772f86ea8069bc1d49ea', 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Det vi gjør", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Vi tilbyr rådgivning og prosjektgjennomføring.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL),
	(1, 3, 'layout', 'en', '6acb772f86ea8069bc1d49ec', 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What we do", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We offer advice and project delivery.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL),
	(1, 4, 'layout', 'no', '6acb773086ea8069bc1d49ee', 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Vi hjelper deg å velge riktig retning.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL),
	(1, 4, 'layout', 'en', '6acb773086ea8069bc1d49f3', 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We help you choose the right direction.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL),
	(1, 5, 'layout', 'no', '6acb773086ea8069bc1d49f8', 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Noen eksempler på hva vi har levert.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL),
	(1, 5, 'layout', 'en', '6acb773086ea8069bc1d49ff', 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Some examples of what we have delivered.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL),
	(1, 7, 'layout', 'no', '6acb773086ea8069bc1d4a0e', 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ring oss på +47 000 00 000 eller skriv til nettsted@example.com.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL),
	(1, 7, 'layout', 'en', '6acb773086ea8069bc1d4a11', 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Call us on +47 000 00 000 or write to nettsted@example.com.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL),
	(1, 8, 'layout', 'no', '6acb773086ea8069bc1d4a14', 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Personvern", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Eksempeltekst. Erstatt med virksomhetens egen personvernerklæring.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL),
	(1, 8, 'layout', 'en', '6acb773086ea8069bc1d4a15', 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Privacy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Example text. Replace with the organisation''s own privacy notice.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL),
	(1, 9, 'layout', 'no', '6acb773086ea8069bc1d4a16', 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Informasjonskapsler", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Vi bruker bare nødvendige informasjonskapsler, og statistikk når du samtykker.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL),
	(1, 9, 'layout', 'en', '6acb773086ea8069bc1d4a17', 'text', 'left', 'none', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Cookies", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use only necessary cookies, and statistics when you consent.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', NULL);
INSERT INTO public.pages_blocks_cta (_order, _parent_id, _path, _locale, id, heading, text, background, align, block_name) VALUES
	(4, 1, 'layout', 'no', '6acb772f86ea8069bc1d49cd', 'Klar for en prat?', 'Vi svarer innen én arbeidsdag.', 'tint', 'center', NULL),
	(4, 1, 'layout', 'en', '6acb772f86ea8069bc1d49d7', 'Ready to talk?', 'We reply within one working day.', 'tint', 'center', NULL);
INSERT INTO public.pages_blocks_cta_links (_order, _parent_id, _locale, id, link_type, link_new_tab, link_url, link_label, link_appearance) VALUES
	(1, '6acb772f86ea8069bc1d49cd', 'no', '6acb772f86ea8069bc1d49cc', 'reference', NULL, NULL, 'Kontakt oss', 'primary'),
	(1, '6acb772f86ea8069bc1d49d7', 'en', '6acb772f86ea8069bc1d49d6', 'reference', NULL, NULL, 'Contact us', 'primary');
INSERT INTO public.pages_blocks_documents (_order, _parent_id, _path, _locale, id, heading, background, block_name) VALUES
	(3, 7, 'layout', 'no', '6acb773086ea8069bc1d4a10', 'Dokumenter', 'none', NULL),
	(3, 7, 'layout', 'en', '6acb773086ea8069bc1d4a13', 'Documents', 'none', NULL);
INSERT INTO public.pages_blocks_embed (_order, _parent_id, _path, _locale, id, heading, provider, url, title, height, block_name) VALUES
	(2, 7, 'layout', 'no', '6acb773086ea8069bc1d4a0f', 'Finn oss', 'google-maps', 'https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d2000!2d18.95!3d69.65!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sno!2sno', 'Kart over Tromsø', 400, NULL),
	(2, 7, 'layout', 'en', '6acb773086ea8069bc1d4a12', 'Find us', 'google-maps', 'https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d2000!2d18.95!3d69.65!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sno!2sno', 'Map of Tromsø', 400, NULL);
INSERT INTO public.pages_blocks_facts (_order, _parent_id, _path, _locale, id, heading, background, block_name) VALUES
	(2, 6, 'layout', 'no', '6acb773086ea8069bc1d4a09', 'Fakta', 'none', NULL),
	(2, 6, 'layout', 'en', '6acb773086ea8069bc1d4a0d', 'Facts', 'none', NULL);
INSERT INTO public.pages_blocks_facts_items (_order, _parent_id, _locale, id, label, value) VALUES
	(1, '6acb773086ea8069bc1d4a09', 'no', '6acb773086ea8069bc1d4a07', 'Ansatte', '2'),
	(2, '6acb773086ea8069bc1d4a09', 'no', '6acb773086ea8069bc1d4a08', 'Kontorer', 'Tromsø og Oslo'),
	(1, '6acb773086ea8069bc1d4a0d', 'en', '6acb773086ea8069bc1d4a0b', 'Employees', '2'),
	(2, '6acb773086ea8069bc1d4a0d', 'en', '6acb773086ea8069bc1d4a0c', 'Offices', 'Tromsø and Oslo');
INSERT INTO public.pages_blocks_full_image (_order, _parent_id, _path, _locale, id, image_id, caption, size, block_name) VALUES
	(3, 5, 'layout', 'no', '6acb773086ea8069bc1d49fd', 1, 'Eksempelbilde', 'wide', NULL),
	(3, 5, 'layout', 'en', '6acb773086ea8069bc1d4a04', 1, 'Example image', 'wide', NULL);
INSERT INTO public.pages_blocks_hero (_order, _parent_id, _path, _locale, id, variant, eyebrow, eyebrow_highlight, heading, text, media_id, align, block_name) VALUES
	(1, 1, 'layout', 'no', '6acb772f86ea8069bc1d49c6', 'image', 'Rådgivning', NULL, 'Vi hjelper virksomheter å lykkes digitalt', 'Nordlys Demo er et eksempelnettsted for Hosait Site Kit.', 1, 'left', NULL),
	(1, 1, 'layout', 'en', '6acb772f86ea8069bc1d49d0', 'image', 'Advisory', NULL, 'We help businesses succeed online', 'Nordlys Demo is an example website for Hosait Site Kit.', 1, 'left', NULL);
INSERT INTO public.pages_blocks_hero_links (_order, _parent_id, _locale, id, link_type, link_new_tab, link_url, link_label, link_appearance) VALUES
	(1, '6acb772f86ea8069bc1d49c6', 'no', '6acb772f86ea8069bc1d49c4', 'reference', NULL, NULL, 'Våre tjenester', 'primary'),
	(2, '6acb772f86ea8069bc1d49c6', 'no', '6acb772f86ea8069bc1d49c5', 'reference', NULL, NULL, 'Kontakt oss', 'primary'),
	(1, '6acb772f86ea8069bc1d49d0', 'en', '6acb772f86ea8069bc1d49ce', 'reference', NULL, NULL, 'Our services', 'primary'),
	(2, '6acb772f86ea8069bc1d49d0', 'en', '6acb772f86ea8069bc1d49cf', 'reference', NULL, NULL, 'Contact us', 'primary');
INSERT INTO public.pages_blocks_image_grid (_order, _parent_id, _path, _locale, id, heading, columns, background, block_name) VALUES
	(2, 5, 'layout', 'no', '6acb773086ea8069bc1d49fc', 'Utvalgte prosjekter', '3', 'none', NULL),
	(2, 5, 'layout', 'en', '6acb773086ea8069bc1d4a03', 'Selected projects', '3', 'none', NULL);
INSERT INTO public.pages_blocks_image_grid_images (_order, _parent_id, _locale, id, image_id, caption) VALUES
	(1, '6acb773086ea8069bc1d49fc', 'no', '6acb773086ea8069bc1d49f9', 4, 'Fjord'),
	(2, '6acb773086ea8069bc1d49fc', 'no', '6acb773086ea8069bc1d49fa', 5, 'Kyst'),
	(3, '6acb773086ea8069bc1d49fc', 'no', '6acb773086ea8069bc1d49fb', 2, 'Kontor'),
	(1, '6acb773086ea8069bc1d4a03', 'en', '6acb773086ea8069bc1d4a00', 4, 'Fjord'),
	(2, '6acb773086ea8069bc1d4a03', 'en', '6acb773086ea8069bc1d4a01', 5, 'Coast'),
	(3, '6acb773086ea8069bc1d4a03', 'en', '6acb773086ea8069bc1d4a02', 2, 'Office');
INSERT INTO public.pages_blocks_people (_order, _parent_id, _path, _locale, id, heading, layout, background, block_name) VALUES
	(1, 6, 'layout', 'no', '6acb773086ea8069bc1d4a06', 'Menneskene bak', 'grid', 'none', NULL),
	(1, 6, 'layout', 'en', '6acb773086ea8069bc1d4a0a', 'The people behind it', 'grid', 'none', NULL);
INSERT INTO public.pages_blocks_quote (_order, _parent_id, _path, _locale, id, quote, author, role, image_id, background, align, block_name) VALUES
	(4, 5, 'layout', 'no', '6acb773086ea8069bc1d49fe', 'De leverte til avtalt tid og pris.', 'Eksempel Kunde AS', 'Kunde', NULL, 'none', 'center', NULL),
	(4, 5, 'layout', 'en', '6acb773086ea8069bc1d4a05', 'They delivered on time and on budget.', 'Eksempel Kunde AS', 'Client', NULL, 'none', 'center', NULL);
INSERT INTO public.pages_blocks_stats (_order, _parent_id, _path, _locale, id, heading, intro, background, align, block_name) VALUES
	(2, 2, 'layout', 'no', '6acb772f86ea8069bc1d49dc', 'I tall', NULL, 'muted', 'left', NULL),
	(2, 2, 'layout', 'en', '6acb772f86ea8069bc1d49e5', 'In numbers', NULL, 'muted', 'left', NULL);
INSERT INTO public.pages_blocks_stats_items (_order, _parent_id, _locale, id, value, label) VALUES
	(1, '6acb772f86ea8069bc1d49dc', 'no', '6acb772f86ea8069bc1d49d9', '15', 'år med erfaring'),
	(2, '6acb772f86ea8069bc1d49dc', 'no', '6acb772f86ea8069bc1d49da', '120', 'prosjekter'),
	(3, '6acb772f86ea8069bc1d49dc', 'no', '6acb772f86ea8069bc1d49db', '2', 'kontorer'),
	(1, '6acb772f86ea8069bc1d49e5', 'en', '6acb772f86ea8069bc1d49e2', '15', 'years of experience'),
	(2, '6acb772f86ea8069bc1d49e5', 'en', '6acb772f86ea8069bc1d49e3', '120', 'projects'),
	(3, '6acb772f86ea8069bc1d49e5', 'en', '6acb772f86ea8069bc1d49e4', '2', 'offices');
INSERT INTO public.pages_blocks_text_image (_order, _parent_id, _path, _locale, id, eyebrow, heading, rich_text, image_id, image_position, layout, background, block_name) VALUES
	(1, 2, 'layout', 'no', '6acb772f86ea8069bc1d49d8', NULL, 'Hvem vi er', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Nordlys Demo er et fiktivt firma laget for å vise hva Site Kit kan.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Alt innhold her er eksempler.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', 2, 'right', 'split', 'none', NULL),
	(1, 2, 'layout', 'en', '6acb772f86ea8069bc1d49e1', NULL, 'Who we are', '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Nordlys Demo is a fictional company made to show what Site Kit can do.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "All content here is an example.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}', 2, 'right', 'split', 'none', NULL);
INSERT INTO public.pages_blocks_timeline (_order, _parent_id, _path, _locale, id, heading, background, block_name) VALUES
	(3, 2, 'layout', 'no', '6acb772f86ea8069bc1d49e0', 'Historien vår', 'none', NULL),
	(3, 2, 'layout', 'en', '6acb772f86ea8069bc1d49e9', 'Our story', 'none', NULL);
INSERT INTO public.pages_blocks_timeline_items (_order, _parent_id, _locale, id, year, title, text, image_id) VALUES
	(1, '6acb772f86ea8069bc1d49e0', 'no', '6acb772f86ea8069bc1d49dd', '2011', 'Oppstart', 'Startet i Tromsø.', NULL),
	(2, '6acb772f86ea8069bc1d49e0', 'no', '6acb772f86ea8069bc1d49de', '2018', 'Nytt kontor', 'Åpnet kontor i Oslo.', NULL),
	(3, '6acb772f86ea8069bc1d49e0', 'no', '6acb772f86ea8069bc1d49df', '2026', 'Hosait', 'Flyttet nettstedet til Hosait.', 5),
	(1, '6acb772f86ea8069bc1d49e9', 'en', '6acb772f86ea8069bc1d49e6', '2011', 'Founded', 'Started in Tromsø.', NULL),
	(2, '6acb772f86ea8069bc1d49e9', 'en', '6acb772f86ea8069bc1d49e7', '2018', 'New office', 'Opened an office in Oslo.', NULL),
	(3, '6acb772f86ea8069bc1d49e9', 'en', '6acb772f86ea8069bc1d49e8', '2026', 'Hosait', 'Moved the website to Hosait.', 5);
INSERT INTO public.pages_blocks_video (_order, _parent_id, _path, _locale, id, heading, url, file_id, poster_id, background, block_name) VALUES
	(3, 4, 'layout', 'no', '6acb773086ea8069bc1d49f2', 'Film: Big Buck Bunny (Blender Foundation, CC BY)', 'https://www.youtube.com/watch?v=aqz-KE-bpKQ', NULL, 5, 'none', NULL),
	(3, 4, 'layout', 'en', '6acb773086ea8069bc1d49f7', 'Film: Big Buck Bunny (Blender Foundation, CC BY)', 'https://www.youtube.com/watch?v=aqz-KE-bpKQ', NULL, 5, 'none', NULL);
INSERT INTO public.pages_locales (title, meta_title, meta_image_id, meta_description, meta_noindex, slug, path, path_override, summary, id, _locale, _parent_id) VALUES
	('Forside', NULL, NULL, NULL, NULL, '', '', NULL, NULL, 30, 'no', 1),
	('Home', NULL, NULL, NULL, NULL, '', '', NULL, NULL, 31, 'en', 1),
	('Om oss', NULL, NULL, NULL, NULL, 'om-oss', 'om-oss', NULL, 'Hvem vi er og hvor vi kommer fra.', 34, 'no', 2),
	('About us', NULL, NULL, NULL, NULL, 'about', 'about', NULL, 'Who we are and where we come from.', 35, 'en', 2),
	('Tjenester', NULL, NULL, NULL, NULL, 'tjenester', 'tjenester', NULL, 'Rådgivning og prosjekter.', 38, 'no', 3),
	('Services', NULL, NULL, NULL, NULL, 'services', 'services', NULL, 'Advice and projects.', 39, 'en', 3),
	('Rådgivning', NULL, NULL, NULL, NULL, 'radgivning', 'tjenester/radgivning', NULL, 'Strategi og planer.', 42, 'no', 4),
	('Advice', NULL, NULL, NULL, NULL, 'advice', 'services/advice', NULL, 'Strategy and plans.', 43, 'en', 4),
	('Prosjekter', NULL, NULL, NULL, NULL, 'prosjekter', 'tjenester/prosjekter', NULL, 'Fra idé til drift.', 46, 'no', 5),
	('Projects', NULL, NULL, NULL, NULL, 'projects', 'services/projects', NULL, 'From idea to operations.', 47, 'en', 5),
	('Folk', NULL, NULL, NULL, NULL, 'folk', 'folk', NULL, NULL, 50, 'no', 6),
	('People', NULL, NULL, NULL, NULL, 'people', 'people', NULL, NULL, 51, 'en', 6),
	('Kontakt', NULL, NULL, NULL, NULL, 'kontakt', 'kontakt', NULL, NULL, 54, 'no', 7),
	('Contact', NULL, NULL, NULL, NULL, 'contact', 'contact', NULL, NULL, 55, 'en', 7),
	('Personvern', NULL, NULL, NULL, NULL, 'personvern', 'personvern', NULL, NULL, 58, 'no', 8),
	('Privacy', NULL, NULL, NULL, NULL, 'privacy', 'privacy', NULL, NULL, 59, 'en', 8),
	('Informasjonskapsler', NULL, NULL, NULL, NULL, 'informasjonskapsler', 'informasjonskapsler', NULL, NULL, 62, 'no', 9),
	('Cookies', NULL, NULL, NULL, NULL, 'cookies', 'cookies', NULL, NULL, 63, 'en', 9);
INSERT INTO public.pages_rels (id, "order", parent_id, path, locale, pages_id, articles_id, people_id, documents_id) VALUES
	(7, NULL, 1, 'layout.0.links.0.link.reference', 'no', 3, NULL, NULL, NULL),
	(8, NULL, 1, 'layout.0.links.1.link.reference', 'no', 7, NULL, NULL, NULL),
	(9, NULL, 1, 'layout.1.items.0.link.reference', 'no', 4, NULL, NULL, NULL),
	(10, NULL, 1, 'layout.1.items.1.link.reference', 'no', 5, NULL, NULL, NULL),
	(11, NULL, 1, 'layout.1.items.2.link.reference', 'no', 2, NULL, NULL, NULL),
	(12, NULL, 1, 'layout.3.links.0.link.reference', 'no', 7, NULL, NULL, NULL),
	(13, NULL, 1, 'layout.0.links.0.link.reference', 'en', 3, NULL, NULL, NULL),
	(14, NULL, 1, 'layout.0.links.1.link.reference', 'en', 7, NULL, NULL, NULL),
	(15, NULL, 1, 'layout.1.items.0.link.reference', 'en', 4, NULL, NULL, NULL),
	(16, NULL, 1, 'layout.1.items.1.link.reference', 'en', 5, NULL, NULL, NULL),
	(17, NULL, 1, 'layout.1.items.2.link.reference', 'en', 2, NULL, NULL, NULL),
	(18, NULL, 1, 'layout.3.links.0.link.reference', 'en', 7, NULL, NULL, NULL),
	(21, 1, 6, 'layout.0.people', 'no', NULL, NULL, 1, NULL),
	(22, 2, 6, 'layout.0.people', 'no', NULL, NULL, 2, NULL),
	(23, 1, 6, 'layout.0.people', 'en', NULL, NULL, 1, NULL),
	(24, 2, 6, 'layout.0.people', 'en', NULL, NULL, 2, NULL),
	(26, 1, 7, 'layout.2.documents', 'no', NULL, NULL, NULL, 1),
	(27, 1, 7, 'layout.2.documents', 'en', NULL, NULL, NULL, 1);
INSERT INTO public.people_locales (role, bio, id, _locale, _parent_id) VALUES
	('Daglig leder', 'Kari leder rådgivningen og har 15 års erfaring.', 2, 'no', 1),
	('Managing director', 'Kari leads our advisory work and has 15 years of experience.', 3, 'en', 1),
	('Prosjektleder', 'Ola styrer prosjektene fra start til slutt.', 5, 'no', 2),
	('Project manager', 'Ola runs our projects from start to finish.', 6, 'en', 2);
INSERT INTO public.redirects (id, site, "from", to_type, to_url, permanent, updated_at, created_at) VALUES
	(1, NULL, '/gammel-side', 'reference', NULL, true, '2026-10-11 11:46:56.827+00', '2026-10-11 11:46:56.826+00');
INSERT INTO public.redirects_rels (id, "order", parent_id, path, pages_id, articles_id) VALUES
	(1, NULL, 1, 'to.reference', 2, NULL);
INSERT INTO public.search_index (id, key, kind, doc_id, locale, site, sites, title, summary, body, path, image_id, date, extra, source, updated_at, created_at) VALUES
	(3, 'people:1:no', 'person', 1, 'no', 'main', ' main ', 'Kari Nordmann', 'Daglig leder', 'Kari leder rådgivningen og har 15 års erfaring.
kari@example.com', NULL, 6, NULL, '{"email": "kari@example.com", "phone": "+47 000 00 001"}', NULL, '2026-10-11 11:46:54.706+00', '2026-10-11 11:46:54.706+00'),
	(4, 'people:1:en', 'person', 1, 'en', 'main', ' main ', 'Kari Nordmann', 'Managing director', 'Kari leads our advisory work and has 15 years of experience.
kari@example.com', NULL, 6, NULL, '{"email": "kari@example.com", "phone": "+47 000 00 001"}', NULL, '2026-10-11 11:46:54.707+00', '2026-10-11 11:46:54.707+00'),
	(7, 'people:2:no', 'person', 2, 'no', 'main', ' main ', 'Ola Nordmann', 'Prosjektleder', 'Ola styrer prosjektene fra start til slutt.
ola@example.com', NULL, 7, NULL, '{"email": "ola@example.com", "phone": "+47 000 00 002"}', NULL, '2026-10-11 11:46:54.729+00', '2026-10-11 11:46:54.729+00'),
	(8, 'people:2:en', 'person', 2, 'en', 'main', ' main ', 'Ola Nordmann', 'Project manager', 'Ola runs our projects from start to finish.
ola@example.com', NULL, 7, NULL, '{"email": "ola@example.com", "phone": "+47 000 00 002"}', NULL, '2026-10-11 11:46:54.73+00', '2026-10-11 11:46:54.73+00'),
	(10, 'documents:1:no', 'document', 1, 'no', 'main', ' main ', 'Brukerveiledning', 'Eksempeldokument.', 'Nordlys Demo - Brukerveiledning / User guide Eksempeldokument for Hosait Site Kit.', '/api/documents/file/brukerveiledning.pdf', NULL, '2026-10-11 11:46:54.804+00', '{"docType": "manual", "filesize": 682, "language": "no", "mimeType": "application/pdf"}', 'brukerveiledning.pdf:682', '2026-10-11 11:46:54.816+00', '2026-10-11 11:46:54.816+00'),
	(11, 'documents:1:en', 'document', 1, 'en', 'main', ' main ', 'User guide', 'Example document.', 'Nordlys Demo - Brukerveiledning / User guide Eksempeldokument for Hosait Site Kit.', '/api/documents/file/brukerveiledning.pdf', NULL, '2026-10-11 11:46:54.804+00', '{"docType": "manual", "filesize": 682, "language": "no", "mimeType": "application/pdf"}', 'brukerveiledning.pdf:682', '2026-10-11 11:46:54.817+00', '2026-10-11 11:46:54.817+00'),
	(41, 'pages:1:no', 'page', 1, 'no', 'main', ' main ', 'Forside', NULL, 'Rådgivning
Vi hjelper virksomheter å lykkes digitalt
Nordlys Demo er et eksempelnettsted for Hosait Site Kit.
Slik kan vi hjelpe
Rådgivning
Strategi og planer som holder.
Prosjekter
Vi leverer fra idé til drift.
Om oss
Et lite team med lang erfaring.
Siste nytt
Klar for en prat?
Vi svarer innen én arbeidsdag.', '/no', NULL, NULL, NULL, NULL, '2026-10-11 11:46:55.763+00', '2026-10-11 11:46:55.763+00'),
	(42, 'pages:1:en', 'page', 1, 'en', 'main', ' main ', 'Home', NULL, 'Advisory
We help businesses succeed online
Nordlys Demo is an example website for Hosait Site Kit.
How we can help
Advice
Strategy and plans that hold up.
Projects
We deliver from idea to operations.
About us
A small team with long experience.
Latest news
Ready to talk?
We reply within one working day.', '/en', NULL, NULL, NULL, NULL, '2026-10-11 11:46:55.764+00', '2026-10-11 11:46:55.764+00'),
	(45, 'pages:2:no', 'page', 2, 'no', 'main', ' main ', 'Om oss', 'Hvem vi er og hvor vi kommer fra.', 'Hvem vi er
Nordlys Demo er et fiktivt firma laget for å vise hva Site Kit kan.
Alt innhold her er eksempler.
I tall
15
år med erfaring
120
prosjekter
2
kontorer
Historien vår
2011
Oppstart
Startet i Tromsø.
2018
Nytt kontor
Åpnet kontor i Oslo.
2026
Hosait
Flyttet nettstedet til Hosait.', '/no/om-oss', 4, NULL, NULL, NULL, '2026-10-11 11:46:55.912+00', '2026-10-11 11:46:55.912+00'),
	(46, 'pages:2:en', 'page', 2, 'en', 'main', ' main ', 'About us', 'Who we are and where we come from.', 'Who we are
Nordlys Demo is a fictional company made to show what Site Kit can do.
All content here is an example.
In numbers
15
years of experience
120
projects
2
offices
Our story
2011
Founded
Started in Tromsø.
2018
New office
Opened an office in Oslo.
2026
Hosait
Moved the website to Hosait.', '/en/about', 4, NULL, NULL, NULL, '2026-10-11 11:46:55.912+00', '2026-10-11 11:46:55.912+00'),
	(49, 'pages:3:no', 'page', 3, 'no', 'main', ' main ', 'Tjenester', 'Rådgivning og prosjekter.', 'Det vi gjør
Vi tilbyr rådgivning og prosjektgjennomføring.
Tjenestene våre', '/no/tjenester', 3, NULL, NULL, NULL, '2026-10-11 11:46:56.02+00', '2026-10-11 11:46:56.02+00'),
	(50, 'pages:3:en', 'page', 3, 'en', 'main', ' main ', 'Services', 'Advice and projects.', 'What we do
We offer advice and project delivery.
Our services', '/en/services', 3, NULL, NULL, NULL, '2026-10-11 11:46:56.021+00', '2026-10-11 11:46:56.021+00'),
	(53, 'pages:4:no', 'page', 4, 'no', 'main', ' main ', 'Rådgivning', 'Strategi og planer.', 'Vi hjelper deg å velge riktig retning.
Vanlige spørsmål
Hva koster det?
Vi gir fast pris etter en første samtale.
Hvor lang tid tar det?
De fleste oppdrag tar 4–8 uker.
Film: Big Buck Bunny (Blender Foundation, CC BY)', '/no/tjenester/radgivning', 3, NULL, NULL, NULL, '2026-10-11 11:46:56.178+00', '2026-10-11 11:46:56.178+00'),
	(54, 'pages:4:en', 'page', 4, 'en', 'main', ' main ', 'Advice', 'Strategy and plans.', 'We help you choose the right direction.
Frequently asked questions
What does it cost?
We give a fixed price after a first conversation.
How long does it take?
Most assignments take 4–8 weeks.
Film: Big Buck Bunny (Blender Foundation, CC BY)', '/en/services/advice', 3, NULL, NULL, NULL, '2026-10-11 11:46:56.179+00', '2026-10-11 11:46:56.179+00'),
	(57, 'pages:5:no', 'page', 5, 'no', 'main', ' main ', 'Prosjekter', 'Fra idé til drift.', 'Noen eksempler på hva vi har levert.
Utvalgte prosjekter
Eksempelbilde
De leverte til avtalt tid og pris.
Eksempel Kunde AS
Kunde', '/no/tjenester/prosjekter', 2, NULL, NULL, NULL, '2026-10-11 11:46:56.307+00', '2026-10-11 11:46:56.307+00'),
	(58, 'pages:5:en', 'page', 5, 'en', 'main', ' main ', 'Projects', 'From idea to operations.', 'Some examples of what we have delivered.
Selected projects
Example image
They delivered on time and on budget.
Eksempel Kunde AS
Client', '/en/services/projects', 2, NULL, NULL, NULL, '2026-10-11 11:46:56.308+00', '2026-10-11 11:46:56.308+00'),
	(61, 'pages:6:no', 'page', 6, 'no', 'main', ' main ', 'Folk', NULL, 'Menneskene bak
Fakta
Ansatte
2
Kontorer
Tromsø og Oslo', '/no/folk', NULL, NULL, NULL, NULL, '2026-10-11 11:46:56.414+00', '2026-10-11 11:46:56.414+00'),
	(62, 'pages:6:en', 'page', 6, 'en', 'main', ' main ', 'People', NULL, 'The people behind it
Facts
Employees
2
Offices
Tromsø and Oslo', '/en/people', NULL, NULL, NULL, NULL, '2026-10-11 11:46:56.415+00', '2026-10-11 11:46:56.415+00'),
	(65, 'pages:7:no', 'page', 7, 'no', 'main', ' main ', 'Kontakt', NULL, 'Ring oss på +47 000 00 000 eller skriv til nettsted@example.com.
Finn oss
Kart over Tromsø
Dokumenter', '/no/kontakt', NULL, NULL, NULL, NULL, '2026-10-11 11:46:56.527+00', '2026-10-11 11:46:56.527+00'),
	(66, 'pages:7:en', 'page', 7, 'en', 'main', ' main ', 'Contact', NULL, 'Call us on +47 000 00 000 or write to nettsted@example.com.
Find us
Map of Tromsø
Documents', '/en/contact', NULL, NULL, NULL, NULL, '2026-10-11 11:46:56.528+00', '2026-10-11 11:46:56.528+00'),
	(69, 'pages:8:no', 'page', 8, 'no', 'main', ' main ', 'Personvern', NULL, 'Personvern
Eksempeltekst. Erstatt med virksomhetens egen personvernerklæring.', '/no/personvern', NULL, NULL, NULL, NULL, '2026-10-11 11:46:56.624+00', '2026-10-11 11:46:56.624+00'),
	(70, 'pages:8:en', 'page', 8, 'en', 'main', ' main ', 'Privacy', NULL, 'Privacy
Example text. Replace with the organisation''s own privacy notice.', '/en/privacy', NULL, NULL, NULL, NULL, '2026-10-11 11:46:56.625+00', '2026-10-11 11:46:56.625+00'),
	(73, 'pages:9:no', 'page', 9, 'no', 'main', ' main ', 'Informasjonskapsler', NULL, 'Informasjonskapsler
Vi bruker bare nødvendige informasjonskapsler, og statistikk når du samtykker.', '/no/informasjonskapsler', NULL, NULL, NULL, NULL, '2026-10-11 11:46:56.72+00', '2026-10-11 11:46:56.72+00'),
	(74, 'pages:9:en', 'page', 9, 'en', 'main', ' main ', 'Cookies', NULL, 'Cookies
We use only necessary cookies, and statistics when you consent.', '/en/cookies', NULL, NULL, NULL, NULL, '2026-10-11 11:46:56.721+00', '2026-10-11 11:46:56.721+00'),
	(76, 'articles:1:no', 'article', 1, 'no', 'main', ' main ', 'Nytt nettsted på Hosait', 'Vi har flyttet nettstedet.', 'Nettstedet kjører nå på Hosait Site Kit.', '/no/nyheter/nytt-nettsted-pa-hosait', 8, '2026-10-01 09:00:00+00', '{"articleKind": "news"}', NULL, '2026-10-11 11:46:56.749+00', '2026-10-11 11:46:56.749+00'),
	(77, 'articles:1:en', 'article', 1, 'en', 'main', ' main ', 'New website on Hosait', 'We have moved our website.', 'The website now runs on Hosait Site Kit.', '/en/news/new-website-on-hosait', 8, '2026-10-01 09:00:00+00', '{"articleKind": "news"}', NULL, '2026-10-11 11:46:56.75+00', '2026-10-11 11:46:56.75+00'),
	(79, 'articles:2:no', 'article', 2, 'no', 'main', ' main ', 'Nytt kontor i Oslo', 'Vi har åpnet kontor i Oslo.', 'Velkommen innom.', '/no/nyheter/nytt-kontor-i-oslo', 2, '2026-09-15 09:00:00+00', '{"articleKind": "news"}', NULL, '2026-10-11 11:46:56.775+00', '2026-10-11 11:46:56.775+00'),
	(80, 'articles:2:en', 'article', 2, 'en', 'main', ' main ', 'New office in Oslo', 'We have opened an office in Oslo.', 'Drop by.', '/en/news/new-office-in-oslo', 2, '2026-09-15 09:00:00+00', '{"articleKind": "news"}', NULL, '2026-10-11 11:46:56.776+00', '2026-10-11 11:46:56.776+00'),
	(82, 'articles:3:no', 'article', 3, 'no', 'main', ' main ', 'Tre råd om digital strategi', 'Kort fortalt.', '1. Start smått
Velg ett mål.
2. Mål
Følg med på tallene.
3. Juster
Gjør små endringer ofte.', '/no/nyheter/tre-rad-om-digital-strategi', 3, '2026-08-20 09:00:00+00', '{"articleKind": "blog"}', NULL, '2026-10-11 11:46:56.803+00', '2026-10-11 11:46:56.803+00'),
	(83, 'articles:3:en', 'article', 3, 'en', 'main', ' main ', 'Three tips on digital strategy', 'In short.', '1. Start small
Pick one goal.
2. Measure
Watch the numbers.
3. Adjust
Make small changes often.', '/en/news/three-tips-on-digital-strategy', 3, '2026-08-20 09:00:00+00', '{"articleKind": "blog"}', NULL, '2026-10-11 11:46:56.804+00', '2026-10-11 11:46:56.804+00');
INSERT INTO public.site_settings (id, site, legal_name, org_number, phone, email, address_street, address_postal_code, address_city, address_country, updated_at, created_at) VALUES
	(1, 'main', 'Nordlys Demo AS', NULL, '+47 000 00 000', 'nettsted@example.com', 'Eksempelveien 1', '9008', 'Tromsø', 'NO', '2026-10-11 11:46:56.818+00', '2026-10-11 11:46:56.807+00');
INSERT INTO public.site_settings_footer_columns (_order, _parent_id, _locale, id, heading) VALUES
	(1, 1, 'no', '6acb773086ea8069bc1d4a1d', 'Nordlys Demo'),
	(2, 1, 'no', '6acb773086ea8069bc1d4a20', 'Juridisk'),
	(1, 1, 'en', '6acb773086ea8069bc1d4a26', 'Nordlys Demo'),
	(2, 1, 'en', '6acb773086ea8069bc1d4a29', 'Legal');
INSERT INTO public.site_settings_footer_columns_links (_order, _parent_id, _locale, id, link_type, link_new_tab, link_url, link_label) VALUES
	(1, '6acb773086ea8069bc1d4a1d', 'no', '6acb773086ea8069bc1d4a1b', 'reference', NULL, NULL, 'Om oss'),
	(2, '6acb773086ea8069bc1d4a1d', 'no', '6acb773086ea8069bc1d4a1c', 'reference', NULL, NULL, 'Kontakt'),
	(1, '6acb773086ea8069bc1d4a20', 'no', '6acb773086ea8069bc1d4a1e', 'reference', NULL, NULL, 'Personvern'),
	(2, '6acb773086ea8069bc1d4a20', 'no', '6acb773086ea8069bc1d4a1f', 'reference', NULL, NULL, 'Informasjonskapsler'),
	(1, '6acb773086ea8069bc1d4a26', 'en', '6acb773086ea8069bc1d4a24', 'reference', NULL, NULL, 'About'),
	(2, '6acb773086ea8069bc1d4a26', 'en', '6acb773086ea8069bc1d4a25', 'reference', NULL, NULL, 'Contact'),
	(1, '6acb773086ea8069bc1d4a29', 'en', '6acb773086ea8069bc1d4a27', 'reference', NULL, NULL, 'Privacy'),
	(2, '6acb773086ea8069bc1d4a29', 'en', '6acb773086ea8069bc1d4a28', 'reference', NULL, NULL, 'Cookies');
INSERT INTO public.site_settings_locales (contact_link_type, contact_link_new_tab, contact_link_url, contact_link_label, copyright, legal, id, _locale, _parent_id) VALUES
	('reference', NULL, NULL, 'Kontakt oss', '© 2026 Nordlys Demo AS', NULL, 2, 'no', 1),
	('reference', NULL, NULL, 'Contact us', '© 2026 Nordlys Demo AS', NULL, 3, 'en', 1);
INSERT INTO public.site_settings_nav (_order, _parent_id, _locale, id, link_type, link_new_tab, link_url, link_label) VALUES
	(1, 1, 'no', '6acb773086ea8069bc1d4a18', 'reference', NULL, NULL, 'Om oss'),
	(2, 1, 'no', '6acb773086ea8069bc1d4a19', 'reference', NULL, NULL, 'Tjenester'),
	(3, 1, 'no', '6acb773086ea8069bc1d4a1a', 'reference', NULL, NULL, 'Folk'),
	(1, 1, 'en', '6acb773086ea8069bc1d4a21', 'reference', NULL, NULL, 'About'),
	(2, 1, 'en', '6acb773086ea8069bc1d4a22', 'reference', NULL, NULL, 'Services'),
	(3, 1, 'en', '6acb773086ea8069bc1d4a23', 'reference', NULL, NULL, 'People');
INSERT INTO public.site_settings_rels (id, "order", parent_id, path, locale, pages_id, articles_id) VALUES
	(9, NULL, 1, 'nav.0.link.reference', 'no', 2, NULL),
	(10, NULL, 1, 'nav.1.link.reference', 'no', 3, NULL),
	(11, NULL, 1, 'nav.2.link.reference', 'no', 6, NULL),
	(12, NULL, 1, 'nav.0.link.reference', 'en', 2, NULL),
	(13, NULL, 1, 'nav.1.link.reference', 'en', 3, NULL),
	(14, NULL, 1, 'nav.2.link.reference', 'en', 6, NULL),
	(15, NULL, 1, 'contactLink.reference', 'no', 7, NULL),
	(16, NULL, 1, 'contactLink.reference', 'en', 7, NULL),
	(17, NULL, 1, 'footerColumns.0.links.0.link.reference', 'no', 2, NULL),
	(18, NULL, 1, 'footerColumns.0.links.1.link.reference', 'no', 7, NULL),
	(19, NULL, 1, 'footerColumns.1.links.0.link.reference', 'no', 8, NULL),
	(20, NULL, 1, 'footerColumns.1.links.1.link.reference', 'no', 9, NULL),
	(21, NULL, 1, 'footerColumns.0.links.0.link.reference', 'en', 2, NULL),
	(22, NULL, 1, 'footerColumns.0.links.1.link.reference', 'en', 7, NULL),
	(23, NULL, 1, 'footerColumns.1.links.0.link.reference', 'en', 8, NULL),
	(24, NULL, 1, 'footerColumns.1.links.1.link.reference', 'en', 9, NULL);
SELECT pg_catalog.setval('public._articles_v_id_seq', 6, true);
SELECT pg_catalog.setval('public._articles_v_locales_id_seq', 9, true);
SELECT pg_catalog.setval('public._pages_v_blocks_accordion_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_accordion_items_id_seq', 6, true);
SELECT pg_catalog.setval('public._pages_v_blocks_article_feed_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_article_feed_sites_id_seq', 1, false);
SELECT pg_catalog.setval('public._pages_v_blocks_cards_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_cards_items_id_seq', 9, true);
SELECT pg_catalog.setval('public._pages_v_blocks_child_pages_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_content_id_seq', 18, true);
SELECT pg_catalog.setval('public._pages_v_blocks_cta_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_cta_links_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_documents_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_embed_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_facts_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_facts_items_id_seq', 6, true);
SELECT pg_catalog.setval('public._pages_v_blocks_form_block_id_seq', 1, false);
SELECT pg_catalog.setval('public._pages_v_blocks_full_image_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_hero_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_hero_links_id_seq', 6, true);
SELECT pg_catalog.setval('public._pages_v_blocks_image_grid_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_image_grid_images_id_seq', 9, true);
SELECT pg_catalog.setval('public._pages_v_blocks_people_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_quote_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_stats_bars_id_seq', 1, false);
SELECT pg_catalog.setval('public._pages_v_blocks_stats_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_stats_items_id_seq', 9, true);
SELECT pg_catalog.setval('public._pages_v_blocks_text_image_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_text_image_links_id_seq', 1, false);
SELECT pg_catalog.setval('public._pages_v_blocks_timeline_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_blocks_timeline_items_id_seq', 9, true);
SELECT pg_catalog.setval('public._pages_v_blocks_video_id_seq', 3, true);
SELECT pg_catalog.setval('public._pages_v_id_seq', 36, true);
SELECT pg_catalog.setval('public._pages_v_locales_id_seq', 63, true);
SELECT pg_catalog.setval('public._pages_v_rels_id_seq', 27, true);
SELECT pg_catalog.setval('public.analytics_daily_id_seq', 1, false);
SELECT pg_catalog.setval('public.analytics_events_id_seq', 1, false);
SELECT pg_catalog.setval('public.analytics_salts_id_seq', 1, false);
SELECT pg_catalog.setval('public.analytics_settings_id_seq', 1, false);
SELECT pg_catalog.setval('public.articles_id_seq', 3, true);
SELECT pg_catalog.setval('public.articles_locales_id_seq', 9, true);
SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);
SELECT pg_catalog.setval('public.consent_log_id_seq', 1, false);
SELECT pg_catalog.setval('public.documents_id_seq', 1, true);
SELECT pg_catalog.setval('public.documents_locales_id_seq', 3, true);
SELECT pg_catalog.setval('public.documents_sites_id_seq', 2, true);
SELECT pg_catalog.setval('public.forms_blocks_checkbox_locales_id_seq', 1, false);
SELECT pg_catalog.setval('public.forms_blocks_country_locales_id_seq', 1, false);
SELECT pg_catalog.setval('public.forms_blocks_email_locales_id_seq', 1, false);
SELECT pg_catalog.setval('public.forms_blocks_message_locales_id_seq', 1, false);
SELECT pg_catalog.setval('public.forms_blocks_number_locales_id_seq', 1, false);
SELECT pg_catalog.setval('public.forms_blocks_select_locales_id_seq', 1, false);
SELECT pg_catalog.setval('public.forms_blocks_select_options_locales_id_seq', 1, false);
SELECT pg_catalog.setval('public.forms_blocks_text_locales_id_seq', 1, false);
SELECT pg_catalog.setval('public.forms_blocks_textarea_locales_id_seq', 1, false);
SELECT pg_catalog.setval('public.forms_emails_locales_id_seq', 1, false);
SELECT pg_catalog.setval('public.forms_id_seq', 1, false);
SELECT pg_catalog.setval('public.forms_locales_id_seq', 1, false);
SELECT pg_catalog.setval('public.media_id_seq', 8, true);
SELECT pg_catalog.setval('public.media_locales_id_seq', 24, true);
SELECT pg_catalog.setval('public.pages_blocks_article_feed_sites_id_seq', 1, false);
SELECT pg_catalog.setval('public.pages_id_seq', 9, true);
SELECT pg_catalog.setval('public.pages_locales_id_seq', 63, true);
SELECT pg_catalog.setval('public.pages_rels_id_seq', 27, true);
SELECT pg_catalog.setval('public.payload_folders_folder_type_id_seq', 1, false);
SELECT pg_catalog.setval('public.payload_folders_id_seq', 1, false);
SELECT pg_catalog.setval('public.people_id_seq', 2, true);
SELECT pg_catalog.setval('public.people_locales_id_seq', 6, true);
SELECT pg_catalog.setval('public.redirects_id_seq', 1, true);
SELECT pg_catalog.setval('public.redirects_rels_id_seq', 1, true);
SELECT pg_catalog.setval('public.search_index_id_seq', 83, true);
SELECT pg_catalog.setval('public.site_settings_id_seq', 1, true);
SELECT pg_catalog.setval('public.site_settings_locales_id_seq', 3, true);
SELECT pg_catalog.setval('public.site_settings_rels_id_seq', 24, true);
SET session_replication_role = 'origin';
UPDATE public.media SET prefix = 'public/media';
UPDATE public.documents SET prefix = 'public/documents';
